
<nav class="navbar navbar" >
  <div class="container-fluid" style="height: auto; background-color: lavender; color: white;">
    <div class="navbar-header">
      <a class="navbar-brand" href="#"><img src="images/ashwani1.png" style="margin-top: -10px"></a>
    </div>
    <ul class="nav navbar-nav" style="margin-top: 10px;">
      <li class="active"><a href="dashbord2.php">Dashbord</a></li>
       <li><a href="#">Search Candidate</a></li> 
      <li><a href="showjob.php">All Posted Job</a></li>
      <li><a href="job.php">Add new Job</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right" style="margin-top: 10px; margin-right:30px; ">
      
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user" sizes="50x50">
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="profile.php">Profile</a></li>
          <li><a href="setting.php">Setting</a></li>
          <li><a href="../login/logout.php">logout</a></li>
        </ul>
      </li>
    </ul>
  </div>
</nav>