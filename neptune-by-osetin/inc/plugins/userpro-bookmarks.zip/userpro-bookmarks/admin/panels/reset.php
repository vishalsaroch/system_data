<div class="upadmin-highlight">
<h4><?php _e('Factory reset ','userpro'); ?></h4>

<p><?php _e('Factory reset setting helps you to clear all users bookmark collections and bookmarks from the system','userpro'); ?></p>
</p>
<a href="admin.php?page=userpro-bookmarks&tab=reset&bookmarklist_act=clear_bookmarklist" class="button"><?php _e('Reset Factory Setting','userpro-fav'); ?></a>
</div>
