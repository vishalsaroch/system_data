<?php
/* Displays user information and some useful messages */
session_start();
// echo session_id();
// Check if user is logged in using the session variable
if ( $_SESSION['logged_in2'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";

  header("location:login2/index.php");  
  exit();
}
else {
    // Makes it easier to read
    $first_name = $_SESSION['first_name'];
    $last_name = $_SESSION['last_name'];
    $email = $_SESSION['email'];
    $active = $_SESSION['active'];
    
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>HairSal &mdash; Colorlib Website Template</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,700,900|Display+Playfair:200,300,400,700"> 
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">

    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/mediaelement@4.2.7/build/mediaelementplayer.min.css">


    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
    <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>

  <script>
  $(function() {
      $("#update").submit(function(e){ 
      // alert("i am in update function");      
        if(location.hostname=='localhost')
          {
             urlkey = "/shop/updateservices.php";
             // alert(" i am in update services");
          }
          else if(location.hostname=='truelook.in')
          {
              urlkey = "updateservices.php";
          }

          $.ajax({
              url: urlkey,
              method: "get",
              success: function(result){
                alert(result);
                      },
              failure: function(result){}
          });

          // return(false);
          alert("Servies Updated Sucessfully");
      
});
});
</script>
</head>
  <body>
 
  <?php 
     
     // Display message about account verification link only once
     if ( isset($_SESSION['message']) )
     {
         echo $_SESSION['message'];
         
         // Don't annoy the user with more messages upon page refresh
         unset( $_SESSION['message'] );
     }
?>
<?php
    // Keep reminding the user this account is not active, until they activate
     if ( !$active ){
         header("location:login2/index.php");
   exit();
     }
     
?>
     <?php
      if($_SERVER['SERVER_NAME']=='localhost'){
              $servername = "localhost";
              $username = "root";
              $password = "";
              $dbname = "shop";
            }
            else if($_SERVER['SERVER_NAME']=='truelook.in')
			{
				$servername = "sun";
				$username = "truelook_root";
				$password = "truelook@12#123";
				$dbname = "truelook_truedb";
			}
            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);
            // Check connection
            if ($conn->connect_error) {
              die("Connection failed: " . $conn->connect_error);
            } 
      ?>
      <?php
         //   if(isset($_POST['submit'])){
         //   $haircutting = 0;
         //   $shving = 0;
         //   $coloring = 0;
         //   $facial = 0;
         //   $drying = 0;
         //   $Bleaching =0; 
         //   $waxing = 0;
         //   $Bridal = 0;
         //   $Treatment =0; 
         //   $Threading = 0;
         //   $wColouring = 0;
         //   $Massage = 0;
         //   $Makeup = 0;
         //   $NailArt = 0;
         //   $Pedicure = 0;
         //   $HairCut = 0;
         //   $spa = 0;

         //   try{
         //   $haircutting = $_POST['haircutting'];
         //   $shving = $_POST['shaving'];
         //   $coloring = $_POST['coloring'];
         //   $facial = $_POST['facial'];
         //   $drying = $_POST['drying'];
         //   $Bleaching = $_POST['Bleaching'];
         //   $waxing = $_POST['waxing'];
         //   $Bridal = $_POST['Bridal'];
         //   $Treatment = $_POST['Treatment'];
         //   $Threading = $_POST['Threading'];
         //   $wColouring = $_POST['wColouring'];
         //   $Massage = $_POST['Massage'];
         //   $Makeup = $_POST['Makeup'];
         //   $NailArt = $_POST['NailArt'];
         //   $Pedicure = $_POST['Pedicure'];
         //   $HairCut = $_POST['HairCut'];
         //   $spa = $_POST['spa'];
         // }catch(Exception $e){
          
         // }
         //   $sql = "UPDATE `shop` SET `HairCutting`='".$haircutting."',`BarberShave`='".$shving."', `HairColoring`='".$coloring."' , `HairDryer`='".$drying."', `Facial`='".$facial."', `BleachingService`='".$Bleaching."', `Bodywaxing`='".$waxing."', `Bridal`='".$Bridal."', `SkinCareTreatment`='".$Treatment."', `FaceThreading`='".$Threading."', `HairColouring`='".$wColouring."',`HeadMassage`='".$Massage."', `Makeup`='".$Makeup."', `NailArt`='".$NailArt."', `Pedicure`='".$Pedicure."', `HairCut`='".$HairCut."', `spa`='".$spa."'WHERE `userid`='".$_SESSION['email']."';";
         //     $run = mysqli_query($conn, $sql);
         //      if ($run) {
         //        echo "<p>Service Activate Sucessfully</p>";
         //        } else {
         //        //echo "Error: " . $sql . "<br>" . $conn->error;
         //        }
         //      }
         
          ?>


  <?php include("nav2.php");?>
   <div class="site-section bg-light">
      <div class="container">
        <div class="row">
         
          <?php
         
          ?>
          <div class="col-md-12">
            
           <?php
            $sql = "SELECT * from shop where mobileno = '".$_SESSION['email']."';";
              $result = $conn->query($sql);
              while($row = $result->fetch_assoc()) {
                $haircitting= $row['HairCutting'];
                // echo $haircitting;
              } 
            ?>
            
             <div class="p-4 mb-3 bg-white">
            
         
          <h3><b>Services</b></h3>
          <form action='' method='post' id='update'>
          <h3>Man</h3>
          <?php
            // if (in_array('1', $haircitting)) {
            //   echo "checked";
            // }
          ?>
         <div class='col-lg-6 ' style="display: inline-block;">
            <input type='checkbox' name='haircutting' value='1' class='check'>
            <label>Hair cutting</label>
            <br>
            <input type='checkbox' name='shaving' value='1' class='check'>
            <label>Shaving</label>
            <br>
            <input type='checkbox' name='coloring' value='1' class='check'>
            <label>haircoloring</label>
            <br>
            
            <input type='checkbox' name='facial' value='1' class='check'>
            <label>Facial</label>
            <br>
            
            <input type='checkbox' name='drying' value='1' class='check'>
            <label>Hairdrying</label>
            <br>
            </div>
            <div class='col-lg-6' style="display: inline-block;">
            <h3>Woman</h3>
                  <input type='checkbox' name='Bleaching' value='1' class='check'>
                  <label>Bleaching Service.</label>
                  <br>
                  <input type='checkbox' name='waxing' value='1' class='check'>
                  <label>Body waxing.</label>
                  <br>
                  <input type='checkbox' name='Bridal' value='1' class='check'>
                  <label>Bridal.</label>
                  <br>
                  
                  <input type='checkbox' name='Threading' value='1' class='check'>
                  <label> Face Threading.</label>
                  <br>
                  
                  <input type='checkbox' name='Treatment' value='1' class='check'>
                  <label>Skin Care Treatment.</label>
                  <br>
                  <input type='checkbox' name='wColouring' value='1' class='check'>
                  <label>Hair Colouring.</label>
                  <br>
                
                  <input type='checkbox' name='Massage' value='1' class='check'>
                  <label>Head Massage.</label>
                  <br>
                  <input type='checkbox' name='Makeup' value='1' class='check'>
                  <label>Makeup.</label>
                  <br>
                  
                  <input type='checkbox' name='NailArt' value='1' class='check'>
                  <label> Nail Art.</label>
                  <br>
                  
                  <input type='checkbox' name='Pedicure' value='1' class='check'>
                  <label>Pedicure.</label>
                  <br>
                  <input type='checkbox' name='HairCut' value='1' class='check'>
                  <label>Hair Cut.</label>
                  <br>
                  <input type='checkbox' name='spa' value='1' class='check'>
                  <label>spa.</label>
                  <br>
                  <input type='submit'  name='submit' value='Activate' class='btn btn-danger' algin='center'>
            </div>
          </form>
        </div>
          </div>
        </div>
      </div>
    </div>
    <?php include("footer.php");?>
  </div>

	<script src="js/aos.js"></script>

  <script src="js/main.js"></script> 
   
  </body>
</html>
