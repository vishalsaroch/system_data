<?php
    if($_SERVER['SERVER_NAME']=='localhost')
  {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "dbase2";
  }
  else if($_SERVER['SERVER_NAME']=='cogentsol.in')
  {
    $servername = "sun";
    $username = "cogentso_root";
    $password = "rootPWD@#";
    $dbname = "cogentso_dbase2";
  }
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Personal Information</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script type="text/javascript">
    function myfunction124(element){
    alert(element.innerHTML);
    document.getElementById("popupfathername").value=element.childNodes[1].innerHTML;
    document.getElementById("popupdob").value=element.childNodes[3].innerHTML;
    document.getElementById("popupgender").value=element.childNodes[5].innerHTML;
    document.getElementById("popupMatricalStatus").value=element.childNodes[7].innerHTML;
    document.getElementById("popupdesignation").value=element.childNodes[9].innerHTML;
    document.getElementById("popupclocation").value=element.childNodes[11].innerHTML;
    document.getElementById("popupaddress").value=element.childNodes[13].innerHTML;
    document.getElementById("popuplocation").value=element.childNodes[15].innerHTML;
    document.getElementById("popupreligion").value=element.childNodes[17].innerHTML;
    document.getElementById("popupnationality").value=element.childNodes[19].innerHTML;
    document.getElementById("popuplanguage").value=element.childNodes[21].innerHTML;
    document.getElementById("popupplocation").value=element.childNodes23].innerHTML;
    document.getElementById("popupnotice").value=element.childNodes[25].innerHTML;
    document.getElementById("popupsalary").value=element.childNodes[27].innerHTML;   
  }
  </script>
  <style type="text/css">
    .close{
      color: white;
    }
    .modal-header{
      background-color: gray;
    }

  </style>
</head>
<body>
<?php 
     
     //Display message about account verification link only once
     if ( isset($_SESSION['message']) )
     {
         echo $_SESSION['message'];
         
         //Don't annoy the user with more messages upon page refresh
         unset( $_SESSION['message'] );
     }
     
     ?>
     
     
     <?php
     
     // Keep reminding the user this account is not active, until they activate
     if ( !$active ){
         header("location:../../login2/index.php");
   exit();
     }
     
     ?>
<div class=container>
  <div class="row">
    <h3 align ='center' style='background-color: #d1e2ff;'>Personal Information</h3>
  
 
 
    <?php
      if(isset($_POST['update'])){
            $fathername=$_POST["fathername"];
            $dob=$_POST['dob'];
            $gender=$_POST['gender'];
            $matricalStatus=$_POST['matricalStatus'];
            $designation=$_POST['designation'];
            $clocation=$_POST['clocation'];
            $address=$_POST['address'];
            $clocation=$_POST['clocation'];
            $religion= $_POST["religion"];
            $nationality=$_POST['nationality'];
            $language=$_POST['language'];
            $plocation=$_POST['plocation'];
            $notice=$_POST['notice'];
            $ExpectedSalary=$_POST['Salary'];
            $date=date("Y/m/d");
            $sql = "UPDATE `candidate` SET `FatherName`='".$fathername."',`DOB`='".$dob."', `Gender`='".$gender."', `maritalStatus`='".$matricalStatus."',`CurrentDesignation`='".$designation."',`CurrentLocation`='".$clocation."',`Address`='".$address."', `Religion`='".$religion."',`Nationality`='".$nationality."',`LanguageKnown`='".$language."',`PreferredLocation`='".$plocation."',`NoticePeriod`='".$notice."',`ExpectedSalary`='".$ExpectedSalary."', `date`='".$date."' WHERE `userid`='".$_SESSION['email']."';";
            // $sql = "UPDATE `candidate` SET `FatherName`='".$fathername."',`DOB`='".$dob."',`Gender`='".$gender."',`MatricalStatus`='".$matricalStatus."',`CurrentDesignation`='".$designation."',`CurrentLocation`='".$clocation."',`Address`='".$address."', `Religion`='".$religion."',`Nationality`='".$nationality."',`LanguageKnown`='".$language."',`PreferredLocation`='".$plocation."',`  NoticePeriod`='".$notice."',`  ExpectedSalary`='".$ExpectedSalary."', `date`='".$date."' WHERE `userid`='".$_SESSION['email']."';";
            
            $run = mysqli_query($conn, $sql);
            if ($run) {
              echo "<p>Personal Information Updated Successfully</p>";
              } else {
              echo "Error: " . $sql . "<br>" . $conn->error;
              }
            }
    ?>

   <?php
                $sql = "SELECT * FROM candidate WHERE candidate.emailid = '".$_SESSION['email']."';";
                   // $sql = "SELECT basicinformation.DOB, basicinformation.MaritalStatus, basicinformation.Address, basicinformation.Religion , basicinformation.Nationality, basicinformation.LanguageKnown, basicinformation.CurrentDesignation,basicinformation.CurrentLocation, basicinformation.FatherName, basicinformation.NoticePeriod, basicinformation.PreferredLocation, basicinformation.ExpectedSalary, basicinformation.gender,basicinformation.MaritalStatus,  candidate.fname, candidate.lname, candidate.emailid, candidate.mobileno, candidate.mobileno, candidate.years, candidate.months FROM basicinformation INNER JOIN candidate ON basicinformation.emailid = candidate.emailid where candidate.emailid = '".$_SESSION['email']."';";
              $result = $conn->query($sql);
              
            if ($result->num_rows > 0) {
              
              while($row = $result->fetch_assoc()) {
                  echo "<div class='row' >
                          <div class='col-md-12' >
                              <div class='col-md-6' style='margin-top:20px; margin-bottom: 20px'>
                                <strong>DOB:</strong><br>". $row["DOB"]."<br>
                                <strong>Father:</strong><br>". $row["FatherName"]."<br>
                                <strong>Gender:</strong><br>" . $row["Gender"]."<br>
                                <strong>MaritalStatus:</strong><br>" . $row["MaritalStatus"]."<br>
                                <strong>Mobile No:</strong><br> " . $row["mobileno"]."<br>
                                <strong>Email:</strong> <br>" . $row["emailid"]."<br>
                                <strong>Address:</strong><br>" . $row["Address"]."<br>
                                <strong>Religion:</strong><br>" . $row["Religion"]."<br>
                                
                              </div>
                              <div class='col-md-6' style='margin-top:20px; margin-bottom: 20px;'>
                                <strong>Nationality:</strong><br>" . $row["Nationality"]."<br>
                                <strong>Language Known:</strong><br>" . $row["LanguageKnown"]."<br>
                                <strong>Current Designation:</strong><br>" . $row["CurrentDesignation"]."<br>
                                <strong>Current Location:</strong><br>" . $row["CurrentLocation"]."<br>
                                <strong>Preferred Location:</strong><br>" . $row["PreferredLocation"]."<br>
                                <strong>Total Experience:</strong><br> " . $row["years"]. ".". $row["months"]." Years<br>
                                <strong>Notice Period:</strong><br>" . $row["NoticePeriod"]." Month<br>
                                <strong>Expected Salary:</strong><br>" . $row["ExpectedSalary"]."</td><br>
                                <div class='row'>
                                  <button type='button' class='btn btn-info btn-lg'  data-toggle='modal' data-target='#myModal8' onclick='myfunction124(this.parentNode.parentNode.parentNode)'><span class='glyphicon glyphicon-edit'></span></button>
                                  <!--  <button type='button' class='btn btn-info btn-lg' onclick='myfunction123(this.parentNode.parentNode)' data-toggle='modal' data-target='#myModal8'  >Edit</button> -->
                                </div>
                            </div>
                            
                              
                        </div>" ;

              }
          } else {
              echo "</table>";
          }
          $conn->close();
          ?>
   
        
        <?php
            
        ?>
        <div class="container">
          <!-- Trigger the modal with a button -->
          
          
            
          <!-- Modal -->
          <div class="modal fade" id="myModal8" role="dialog" style="padding:10px;">
            <div class="modal-dialog">
            
              <!-- Modal content-->
              <div class="modal-content" >
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title" align="center">Basic Information</h4>
                </div>
                <div class="modal-body">
                 <form method="post" action="">

                 <div class="row">
                  <div class="col-md-6">
                      <strong><lable>Father Name:</lable></strong>
                      <input type="text" name="fathername" id="popupfathername" class="form-control"" class="form-control">
                      <strong><lable>DOB:</lable></strong>
                      <input type="date" name="dob" id="popupdob" class="form-control">
                      <strong><lable>Gender:</lable></strong><br><br>
                       <!-- <input type="text" name="gender" class="form-control"> -->
                      <label class="radio-inline" style="text-indent: 25px;"><input type="radio" name="gender" id="popupgender" value="male" class="radio">Male</label>
                      
                      <label class="radio-inline" style="text-indent: 40px;"><input type="radio" name="gender" id="popupgender"  value="female" class="radio">Female</label>
                      <br><br>
                      <strong><lable>Matrical Status:</lable></strong>
                      <input type="text" name="matricalStatus" id="popupMatricalStatus" class="form-control">
                      <strong><lable>Current Designation:</lable></strong>
                      <input type="text" name="designation" id="popupdesignation" class="form-control">
                      <strong><lable>Current Location :</lable></strong>
                      <input type="text" name="clocation" id="popupclocation" class="form-control">
                      <strong><lable>Current Address:</lable></strong>
                      <input type="text" name="address" id="popupaddress" class="form-control">
                  </div> 

                  <div class="col-md-6">  
                      <strong><lable>Current Location:</lable></strong>
                      <input type="text" name="clocation" id="popuplocation" class="form-control">
                      <strong><lable>Religion:</lable></strong>
                      <input type="text" name="religion" id="popupreligion" class="form-control">
                      <strong><lable>Nationality:</lable></strong>
                      <input type="text" name="nationality" id="popupnationality" class="form-control">
                      <strong><lable>Language:</lable></strong>
                      <input type="text" name="language" id="popuplanguage" class="form-control">
                      <strong><lable>PreferredLocation:</lable></strong>
                      <input type="text" name="plocation" id="popupplocation" class="form-control">
                      <strong><lable>NoticePeriod:</lable></strong></td>
                      <input type="text" name="notice"  id="popupnotice"class="form-control">
                      <strong><lable>ExpectedSalary:</lable></strong>
                      <input type="text" name="Salary" id="popupsalary" class="form-control">
                      <input type="submit" name="update" id="update" value="Update" class="btn btn-info text-right" >
                   </div>
                </div>     
                    </form>
                </div>
                  </div>
              </div>
              </div>
            </div>
          </div>
        </div>  
        </div>
        </div>

</body>
</html>