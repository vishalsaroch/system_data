<?php

echo $_POST["data"];
// echo $_GET["data"];

?>