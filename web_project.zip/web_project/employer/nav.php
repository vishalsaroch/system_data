
<nav class="navbar navbar-fixed-top navbar-inverse">                                                                                   
   <div class="container-fluid">
    <div class="navbar-header">
    <a class="navbar-brand" href="index.php"><img src="images/ashwani.png" style=" width:180px; margin-top:-10px;"></a>
      <button style="border: 1px blue solid; margin-top: -30px; width: 15%;" type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar"> 
        <span style="background-color: blue;" class="icon-bar"></span>
        <span style="background-color: blue;" class="icon-bar"></span>
        <span style="background-color: blue;" class="icon-bar"></span>                        
      </button>
      
      </div>
      <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav navbar-nav" style="margin-top: 10px; font-weight: bold;">
      <?php echo '<li class="active"><a href="dashbord2.php" ".$temp.">Dashbord</a></li>'?>
      <li><a href="advancesearch.php">Search Candidate</a></li> 
      <li><a href="showjob.php">My Posted Job</a></li>
      <li><a href="job.php">Add new Job</a></li>
      <li><a href="profile.php">Profile</a></li>
      
    </ul>
    <ul class="nav navbar-nav navbar-right" style="margin-top: 10px; font-weight: bold;">
        <li><a href="../login/logout.php"><span class="glyphicon glyphicon-log-out"> Logout</a></li>
      </ul>
      </div>
    </div>
  </nav>
  <!-- <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
     <a class="navbar-brand" href="#"><img src="images/ashwani.png" style="width:170px;"></a>
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
     
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">Home</a></li>
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Page 1 <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="#">Page 1-1</a></li>
            <li><a href="#">Page 1-2</a></li>
            <li><a href="#">Page 1-3</a></li>
          </ul>
        </li>
        <li><a href="#">Page 2</a></li>
        <li><a href="#">Page 3</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
        <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
      </ul>
    </div>
  </div>
</nav> -->

