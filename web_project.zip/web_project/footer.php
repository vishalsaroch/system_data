<section id="footer">
	<div class="container">
		<div class="row text-center text-xs-center text-sm-left text-md-left">
			<div class="col-sm-6 col-md-6">
				<ul class="list-unstyled quick-links text-left">
					<li><a href="index.php"><i class="fa fa-angle-double-right"></i>Home</a></li>
					<li><a href="about.html"><i class="fa fa-angle-double-right"></i>About</a></li>
					<li><a href="requirment.php"><i class="fa fa-angle-double-right"></i>Recruitment & Staffing</a></li>
					<li><a href="traning.php;"><i class="fa fa-angle-double-right"></i>Training</a></li>
					<li><a href="payroll.php"><i class="fa fa-angle-double-right"></i>Payroll & Statutory Compliance</a></li>
				</ul>
			</div>
			<div class="col-xs-12 col-sm-6 col-md-6">
				<ul class="list-unstyled list-inline social text-center">
					<li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-facebook"></i></a></li><br>
					<li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-twitter"></i></a></li><br>
					<li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-instagram"></i></a></li><br>
					<li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-google-plus"></i></a></li><br>
				</ul>
			</div>
			<div class="col-sm-12 text-center">
				<h4 style="color:#fff;"><a href="http://www.realkeeper.in/" target="_blank"> Realkeeper Technologies Pvt. Ltd</a></h4>
			</div>	
		</div>
	</div>	
</section>	