<?php
/* Registration process, inserts user info into the database 
   and sends account confirmation email message
 */