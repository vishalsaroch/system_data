<?php

if($_SERVER['SERVER_NAME']=='localhost')
	{
		$servername = "localhost";
		$username = "root";
		$password = "";
		$dbname = "dbase2";
	}
	else if($_SERVER['SERVER_NAME']=='cogentsol.in')
	{
		$servername = "sun";
		$username = "cogentso_root";
		$password = "rootPWD@#";
		$dbname = "cogentso_dbase2";
	}
		// Create connection
		$conn = new mysqli($servername, $username, $password, $dbname);
		// Check connection
		if ($conn->connect_error) {
		    die("Connection failed: " . $conn->connect_error);
		} 
if(isset($_POST['submit']))
{
	$userid=$_POST['emailid'];
	$pwd=$_POST['password'];
	$name=$_POST['name'];
	$compName=$_POST['compName'];
	$contactNo=$_POST['contactNo'];
	$role=$_POST['role'];
	$date=date("Y/m/d");
	$msg="";
	 $sql = "SELECT * from `employersusers` WHERE emailid = '".$userid."'";		
	 $result1 = $conn->query($sql);
	  if ($result1->num_rows > 0) {
	  	$msg="Email id already exist.";
	  } else {
		$sql = "INSERT INTO `employersusers` (`compName`, `username`, `emailid`, `contactNo`, `userid`, `pwd`, `date`, `role`) VALUES ('$compName', '$name', '$userid', '$contactNo', '$userid', '$pwd' , '$date' , '$role')";
			
		if ($conn->query($sql) === TRUE) {
		    echo "Compamy Register Successfully";
		    header("location:employee/profile.php");
		} else {
		    echo "Error: " . $sql . "<br>" . $conn->error;
		}
	}
	    $conn->close(); 
}   
?>