﻿<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->

<!-- BEGIN HEAD-->
<head>
     <meta charset="UTF-8" />
    <title>BCORE Admin Dashboard Template | Buttons</title>
     <meta content="width=device-width, initial-scale=1.0" name="viewport" />
	<meta content="" name="description" />
	<meta content="" name="author" />
     <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <!-- GLOBAL STYLES -->
    <!-- GLOBAL STYLES -->
    <link rel="stylesheet" href="assets/plugins/bootstrap/css/bootstrap.css" />
    <link rel="stylesheet" href="assets/css/main.css" />
    <link rel="stylesheet" href="assets/css/theme.css" />
    <link rel="stylesheet" href="assets/css/MoneAdmin.css" />
    <link rel="stylesheet" href="assets/plugins/Font-Awesome/css/font-awesome.css" />
    <!--END GLOBAL STYLES -->

    <!-- PAGE LEVEL STYLES -->
    <link rel="stylesheet" href="assets/plugins/social-buttons/social-buttons.css" />
    <!-- END PAGE LEVEL  STYLES -->
       <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
   
</head>
    <!-- END HEAD-->
    <!-- BEGIN BODY-->
<body class="padTop53 " >

 <!-- MAIN WRAPPER -->
    <div id="wrap">

          <!-- HEADER SECTION -->
        <div id="top">

            <nav class="navbar navbar-inverse navbar-fixed-top " style="padding-top: 10px;">
                <a data-original-title="Show/Hide Menu" data-placement="bottom" data-tooltip="tooltip" class="accordion-toggle btn btn-primary btn-sm visible-xs" data-toggle="collapse" href="#menu" id="menu-toggle">
                    <i class="icon-align-justify"></i>
                </a>
                <!-- LOGO SECTION -->
                <header class="navbar-header">

                    <a href="index.html" class="navbar-brand">
                    <img src="assets/img/logo.png" alt="" /></a>
                </header>
                <!-- END LOGO SECTION -->
                <ul class="nav navbar-top-links navbar-right">

                    <!-- MESSAGES SECTION -->
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <span class="label label-success">2</span>    <i class="icon-envelope-alt"></i>&nbsp; <i class="icon-chevron-down"></i>
                        </a>

                        <ul class="dropdown-menu dropdown-messages">
                            <li>
                                <a href="#">
                                    <div>
                                       <strong>John Smith</strong>
                                        <span class="pull-right text-muted">
                                            <em>Today</em>
                                        </span>
                                    </div>
                                    <div>Lorem ipsum dolor sit amet, consectetur adipiscing.
                                        <br />
                                        <span class="label label-primary">Important</span> 

                                    </div>
                                </a>
                            </li>
                            <li class="divider"></li>
                            <li>
                                <a href="#">
                                    <div>
                                        <strong>Raphel Jonson</strong>
                                        <span class="pull-right text-muted">
                                            <em>Yesterday</em>
                                        </span>
                                    </div>
                                    <div>Lorem ipsum dolor sit amet, consectetur adipiscing.
                                         <br />
                                        <span class="label label-success"> Moderate </span> 
                                    </div>
                                </a>
                            </li>
                            <li class="divider"></li>
                            <li>
                                <a href="#">
                                    <div>
                                        <strong>Chi Ley Suk</strong>
                                        <span class="pull-right text-muted">
                                            <em>26 Jan 2014</em>
                                        </span>
                                    </div>
                                    <div>Lorem ipsum dolor sit amet, consectetur adipiscing.
                                         <br />
                                        <span class="label label-danger"> Low </span> 
                                    </div>
                                </a>
                            </li>
                            <li class="divider"></li>
                            <li>
                                <a class="text-center" href="#">
                                    <strong>Read All Messages</strong>
                                    <i class="icon-angle-right"></i>
                                </a>
                            </li>
                        </ul>

                    </li>
                    <!--END MESSAGES SECTION -->

                    <!--TASK SECTION -->
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <span class="label label-danger">5</span>   <i class="icon-tasks"></i>&nbsp; <i class="icon-chevron-down"></i>
                        </a>

                        <ul class="dropdown-menu dropdown-tasks">
                            <li>
                                <a href="#">
                                    <div>
                                        <p>
                                            <strong> Profile </strong>
                                            <span class="pull-right text-muted">40% Complete</span>
                                        </p>
                                        <div class="progress progress-striped active">
                                            <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%">
                                                <span class="sr-only">40% Complete (success)</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li class="divider"></li>
                            <li>
                                <a href="#">
                                    <div>
                                        <p>
                                            <strong> Pending Tasks </strong>
                                            <span class="pull-right text-muted">20% Complete</span>
                                        </p>
                                        <div class="progress progress-striped active">
                                            <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100" style="width: 20%">
                                                <span class="sr-only">20% Complete</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li class="divider"></li>
                            <li>
                                <a href="#">
                                    <div>
                                        <p>
                                            <strong> Work Completed </strong>
                                            <span class="pull-right text-muted">60% Complete</span>
                                        </p>
                                        <div class="progress progress-striped active">
                                            <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%">
                                                <span class="sr-only">60% Complete (warning)</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li class="divider"></li>
                            <li>
                                <a href="#">
                                    <div>
                                        <p>
                                            <strong> Summary </strong>
                                            <span class="pull-right text-muted">80% Complete</span>
                                        </p>
                                        <div class="progress progress-striped active">
                                            <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%">
                                                <span class="sr-only">80% Complete (danger)</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li class="divider"></li>
                            <li>
                                <a class="text-center" href="#">
                                    <strong>See All Tasks</strong>
                                    <i class="icon-angle-right"></i>
                                </a>
                            </li>
                        </ul>

                    </li>
                    <!--END TASK SECTION -->

                    <!--ALERTS SECTION -->
                    <li class="chat-panel dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <span class="label label-info">8</span>   <i class="icon-comments"></i>&nbsp; <i class="icon-chevron-down"></i>
                        </a>

                        <ul class="dropdown-menu dropdown-alerts">

                            <li>
                                <a href="#">
                                    <div>
                                        <i class="icon-comment" ></i> New Comment
                                    <span class="pull-right text-muted small"> 4 minutes ago</span>
                                    </div>
                                </a>
                            </li>
                            <li class="divider"></li>
                            <li>
                                <a href="#">
                                    <div>
                                        <i class="icon-twitter info"></i> 3 New Follower
                                    <span class="pull-right text-muted small"> 9 minutes ago</span>
                                    </div>
                                </a>
                            </li>
                            <li class="divider"></li>
                            <li>
                                <a href="#">
                                    <div>
                                        <i class="icon-envelope"></i> Message Sent
                                    <span class="pull-right text-muted small" > 20 minutes ago</span>
                                    </div>
                                </a>
                            </li>
                            <li class="divider"></li>
                            <li>
                                <a href="#">
                                    <div>
                                        <i class="icon-tasks"></i> New Task
                                    <span class="pull-right text-muted small"> 1 Hour ago</span>
                                    </div>
                                </a>
                            </li>
                            <li class="divider"></li>
                            <li>
                                <a href="#">
                                    <div>
                                        <i class="icon-upload"></i> Server Rebooted
                                    <span class="pull-right text-muted small"> 2 Hour ago</span>
                                    </div>
                                </a>
                            </li>
                            <li class="divider"></li>
                            <li>
                                <a class="text-center" href="#">
                                    <strong>See All Alerts</strong>
                                    <i class="icon-angle-right"></i>
                                </a>
                            </li>
                        </ul>

                    </li>
                    <!-- END ALERTS SECTION -->

                    <!--ADMIN SETTINGS SECTIONS -->

                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <i class="icon-user "></i>&nbsp; <i class="icon-chevron-down "></i>
                        </a>

                        <ul class="dropdown-menu dropdown-user">
                            <li><a href="#"><i class="icon-user"></i> User Profile </a>
                            </li>
                            <li><a href="#"><i class="icon-gear"></i> Settings </a>
                            </li>
                            <li class="divider"></li>
                            <li><a href="login.html"><i class="icon-signout"></i> Logout </a>
                            </li>
                        </ul>

                    </li>
                    <!--END ADMIN SETTINGS -->
                </ul>

            </nav>

        </div>
        <!-- END HEADER SECTION -->



        <!-- MENU SECTION -->
       <div id="left">
            <div class="media user-media well-small">
                <a class="user-link" href="#">
                    <img class="media-object img-thumbnail user-img" alt="User Picture" src="assets/img/user.gif" />
                </a>
                <br />
                <div class="media-body">
                    <h5 class="media-heading"> Joe Romlin</h5>
                    <ul class="list-unstyled user-info">
                        
                        <li>
                             <a class="btn btn-success btn-xs btn-circle" style="width: 10px;height: 12px;"></a> Online
                           
                        </li>
                       
                    </ul>
                </div>
                <br />
            </div>

            <ul id="menu" class="collapse">

                
                <li class="panel">
                    <a href="index.html" >
                        <i class="icon-table"></i> Dashboard
	   
                       
                    </a>                   
                </li>



                <li class="panel active">
                    <a href="#" data-parent="#menu" data-toggle="collapse" class="accordion-toggle" data-target="#component-nav">
                        <i class="icon-tasks"> </i> UI Elements     
	   
                        <span class="pull-right">
                          <i class="icon-angle-left"></i>
                        </span>
                       &nbsp; <span class="label label-default">10</span>&nbsp;
                    </a>
                    <ul class="in" id="component-nav">
                       
                        <li class=""><a href="button.html"><i class="icon-angle-right"></i> Buttons </a></li>
                         <li class=""><a href="icon.html"><i class="icon-angle-right"></i> Icons </a></li>
                        <li class=""><a href="progress.html"><i class="icon-angle-right"></i> Progress </a></li>
                        <li class=""><a href="tabs_panels.html"><i class="icon-angle-right"></i> Tabs & Panels </a></li>
                        <li class=""><a href="notifications.html"><i class="icon-angle-right"></i> Notification </a></li>
                         <li class=""><a href="more_notifications.html"><i class="icon-angle-right"></i> More Notification </a></li>
                        <li class=""><a href="modals.html"><i class="icon-angle-right"></i> Modals </a></li>
                          <li class=""><a href="wizard.html"><i class="icon-angle-right"></i> Wizard </a></li>
                         <li class=""><a href="sliders.html"><i class="icon-angle-right"></i> Sliders </a></li>
                        <li class=""><a href="typography.html"><i class="icon-angle-right"></i> Typography </a></li>
                    </ul>
                </li>
                <li class="panel ">
                    <a href="#" data-parent="#menu" data-toggle="collapse" class="accordion-toggle collapsed" data-target="#form-nav">
                        <i class="icon-pencil"></i> Forms
	   
                        <span class="pull-right">
                            <i class="icon-angle-left"></i>
                        </span>
                          &nbsp; <span class="label label-success">5</span>&nbsp;
                    </a>
                    <ul class="collapse" id="form-nav">
                        <li class=""><a href="forms_general.html"><i class="icon-angle-right"></i> General </a></li>
                        <li class=""><a href="forms_advance.html"><i class="icon-angle-right"></i> Advance </a></li>
                        <li class=""><a href="forms_validation.html"><i class="icon-angle-right"></i> Validation </a></li>
                        <li class=""><a href="forms_fileupload.html"><i class="icon-angle-right"></i> FileUpload </a></li>
                        <li class=""><a href="forms_editors.html"><i class="icon-angle-right"></i> WYSIWYG / Editor </a></li>
                    </ul>
                </li>

                <li class="panel">
                    <a href="#" data-parent="#menu" data-toggle="collapse" class="accordion-toggle" data-target="#pagesr-nav">
                        <i class="icon-table"></i> Pages
	   
                        <span class="pull-right">
                            <i class="icon-angle-left"></i>
                        </span>
                          &nbsp; <span class="label label-info">6</span>&nbsp;
                    </a>
                    <ul class="collapse" id="pagesr-nav">
                        <li><a href="pages_calendar.html"><i class="icon-angle-right"></i> Calendar </a></li>
                        <li><a href="pages_timeline.html"><i class="icon-angle-right"></i> Timeline </a></li>
                        <li><a href="pages_social.html"><i class="icon-angle-right"></i> Social </a></li>
                        <li><a href="pages_pricing.html"><i class="icon-angle-right"></i> Pricing </a></li>
                        <li><a href="pages_offline.html"><i class="icon-angle-right"></i> Offline </a></li>
                        <li><a href="pages_uc.html"><i class="icon-angle-right"></i> Under Construction </a></li>
                    </ul>
                </li>
                <li class="panel">
                    <a href="#" data-parent="#menu" data-toggle="collapse" class="accordion-toggle" data-target="#chart-nav">
                        <i class="icon-bar-chart"></i> Charts
	   
                        <span class="pull-right">
                            <i class="icon-angle-left"></i>
                        </span>
                          &nbsp; <span class="label label-danger">4</span>&nbsp;
                    </a>
                    <ul class="collapse" id="chart-nav">



                        <li><a href="charts_line.html"><i class="icon-angle-right"></i> Line Charts </a></li>
                        <li><a href="charts_bar.html"><i class="icon-angle-right"></i> Bar Charts</a></li>
                        <li><a href="charts_pie.html"><i class="icon-angle-right"></i> Pie Charts </a></li>
                        <li><a href="charts_other.html"><i class="icon-angle-right"></i> other Charts </a></li>
                    </ul>
                </li>

                <li class="panel">
                    <a href="#" data-parent="#menu" data-toggle="collapse" class="accordion-toggle" data-target="#DDL-nav">
                        <i class=" icon-sitemap"></i> 3 Level Menu
	   
                        <span class="pull-right">
                            <i class="icon-angle-left"></i>
                        </span>
                    </a>
                    <ul class="collapse" id="DDL-nav">
                        <li>
                            <a href="#" data-parent="#DDL-nav" data-toggle="collapse" class="accordion-toggle" data-target="#DDL1-nav">
                                <i class="icon-sitemap"></i>&nbsp; Demo Link 1
	   
                        <span class="pull-right" style="margin-right: 20px;">
                            <i class="icon-angle-left"></i>
                        </span>


                            </a>
                            <ul class="collapse" id="DDL1-nav">
                                <li>
                                    <a href="#"><i class="icon-angle-right"></i> Demo Link 1 </a>

                                </li>
                                <li>
                                    <a href="#"><i class="icon-angle-right"></i> Demo Link 2 </a></li>
                                <li>
                                    <a href="#"><i class="icon-angle-right"></i> Demo Link 3 </a></li>

                            </ul>

                        </li>
                        <li><a href="#"><i class="icon-angle-right"></i> Demo Link 2 </a></li>
                        <li><a href="#"><i class="icon-angle-right"></i> Demo Link 3 </a></li>
                        <li><a href="#"><i class="icon-angle-right"></i> Demo Link 4 </a></li>
                    </ul>
                </li>
                <li class="panel">
                    <a href="#" data-parent="#menu" data-toggle="collapse" class="accordion-toggle" data-target="#DDL4-nav">
                        <i class=" icon-folder-open-alt"></i> 4 Level Menu
	   
                        <span class="pull-right">
                            <i class="icon-angle-left"></i>
                        </span>
                    </a>
                    <ul class="collapse" id="DDL4-nav">
                        <li>
                            <a href="#" data-parent="DDL4-nav" data-toggle="collapse" class="accordion-toggle" data-target="#DDL4_1-nav">
                                <i class="icon-sitemap"></i>&nbsp; Demo Link 1
	   
                        <span class="pull-right" style="margin-right: 20px;">
                            <i class="icon-angle-left"></i>
                        </span>


                            </a>
                            <ul class="collapse" id="DDL4_1-nav">
                                <li>

                                    <a href="#" data-parent="#DDL4_1-nav" data-toggle="collapse" class="accordion-toggle" data-target="#DDL4_2-nav">
                                        <i class="icon-sitemap"></i>&nbsp; Demo Link 1
	   
                        <span class="pull-right" style="margin-right: 20px;">
                            <i class="icon-angle-left"></i>
                        </span>
                                    </a>
                                    <ul class="collapse" id="DDL4_2-nav">



                                        <li><a href="#"><i class="icon-angle-right"></i> Demo Link 1 </a></li>
                                        <li><a href="#"><i class="icon-angle-right"></i> Demo Link 2 </a></li>
                                    </ul>



                                </li>
                                <li><a href="#"><i class="icon-angle-right"></i> Demo Link 2 </a></li>
                                <li><a href="#"><i class="icon-angle-right"></i> Demo Link 3 </a></li>
                            </ul>

                        </li>
                        <li><a href="#"><i class="icon-angle-right"></i> Demo Link 2 </a></li>
                        <li><a href="#"><i class="icon-angle-right"></i> Demo Link 3 </a></li>
                        <li><a href="#"><i class="icon-angle-right"></i> Demo Link 4 </a></li>
                    </ul>
                </li>
                <li class="panel">
                    <a href="#" data-parent="#menu" data-toggle="collapse" class="accordion-toggle" data-target="#error-nav">
                        <i class="icon-warning-sign"></i> Error Pages
	   
                        <span class="pull-right">
                            <i class="icon-angle-left"></i>
                        </span>
                          &nbsp; <span class="label label-warning">5</span>&nbsp;
                    </a>
                    <ul class="collapse" id="error-nav">
                        <li><a href="errors_403.html"><i class="icon-angle-right"></i> Error 403  </a></li>
                        <li><a href="errors_404.html"><i class="icon-angle-right"></i> Error 404  </a></li>
                        <li><a href="errors_405.html"><i class="icon-angle-right"></i> Error 405  </a></li>
                        <li><a href="errors_500.html"><i class="icon-angle-right"></i> Error 500  </a></li>
                        <li><a href="errors_503.html"><i class="icon-angle-right"></i> Error 503  </a></li>
                    </ul>
                </li>


                <li><a href="gallery.html"><i class="icon-film"></i> Image Gallery </a></li>
                <li><a href="tables.html"><i class="icon-table"></i> Data Tables </a></li>
                <li><a href="maps.html"><i class="icon-map-marker"></i> Maps </a></li>

                <li><a href="grid.html"><i class="icon-columns"></i> Grid </a></li>
                 <li class="panel">
                    <a href="#" data-parent="#menu" data-toggle="collapse" class="accordion-toggle" data-target="#blank-nav">
                        <i class="icon-check-empty"></i> Blank Pages
	   
                        <span class="pull-right">
                            <i class="icon-angle-left"></i>
                        </span>
                         &nbsp; <span class="label label-success">2</span>&nbsp;
                    </a>
                    <ul class="collapse" id="blank-nav">
                       
                        <li><a href="blank.html"><i class="icon-angle-right"></i> Blank Page One  </a></li>
                        <li><a href="blank2.html"><i class="icon-angle-right"></i> Blank Page Two  </a></li>
                    </ul>
                </li>
                <li><a href="login.html"><i class="icon-signin"></i> Login Page </a></li>

            </ul>

        </div>
        <!--END MENU SECTION -->

        <!--PAGE CONTENT -->
        <div id="content">
           
                <div class="inner">
                    <div class="row">
                    <div class="col-lg-12">
                            
                               
                                    <h2 > Buttons </h2>
                                  
                                
                                
                            </div>
                    </div>
                          <hr />
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="panel panel-default">
                        <div class="panel-heading">
                            Circle Icon Buttons 
                        </div>
                       
                        <div class="panel-body">
                            <h4>Normal Circle Buttons</h4>
                            <button type="button" class="btn btn-default btn-circle"><i class="icon-check"></i>
                            </button>
                            <button type="button" class="btn btn-primary btn-circle"><i class="icon-list"></i>
                            </button>
                            <button type="button" class="btn btn-success btn-circle"><i class="icon-link"></i>
                            </button>
                            <button type="button" class="btn btn-info btn-circle"><i class="icon-check"></i>
                            </button>
                            <button type="button" class="btn btn-warning btn-circle"><i class="icon-time"></i>
                            </button>
                            <button type="button" class="btn btn-danger btn-circle"><i class="icon-heart"></i>
                            </button>
                            <br />
                            <br />
                            <h4>Large Circle Buttons</h4>
                            <button type="button" class="btn btn-default btn-circle btn-lg"><i class="icon-check"></i>
                            </button>
                            <button type="button" class="btn btn-primary btn-circle btn-lg"><i class="icon-list"></i>
                            </button>
                            <button type="button" class="btn btn-success btn-circle btn-lg"><i class="icon-link"></i>
                            </button>
                            <button type="button" class="btn btn-info btn-circle btn-lg"><i class="icon-check"></i>
                            </button>
                            <button type="button" class="btn btn-warning btn-circle btn-lg"><i class="icon-time"></i>
                            </button>
                            <button type="button" class="btn btn-danger btn-circle btn-lg"><i class="icon-heart"></i>
                            </button>
                            <br />
                            <br />
                            <h4>Extra Large Circle Buttons</h4>
                            <button type="button" class="btn btn-default btn-circle btn-xl"><i class="icon-check"></i>
                            </button>
                            <button type="button" class="btn btn-primary btn-circle btn-xl"><i class="icon-list"></i>
                            </button>
                            <button type="button" class="btn btn-success btn-circle btn-xl"><i class="icon-link"></i>
                            </button>
                            <button type="button" class="btn btn-info btn-circle btn-xl"><i class="icon-check"></i>
                            </button>
                            <button type="button" class="btn btn-warning btn-circle btn-xl"><i class="icon-time"></i>
                            </button>
                            <button type="button" class="btn btn-danger btn-circle btn-xl"><i class="icon-heart"></i>
                            </button>
                        </div>
                        
                    </div>
                            
                        </div>
                        <div class="col-lg-6">
                                <div class="panel panel-default">
                        <div class="panel-heading">
                           Button Dropdowns
                        </div>        
                                      
                                    <div class="panel-body">   
                                       <div style="margin-top: 10px;">
											<div class="btn-group">
											  <button data-toggle="dropdown" class="btn dropdown-toggle">Action <span class="caret"></span></button>
											  <ul class="dropdown-menu">
												<li><a href="#">Action</a></li>
												<li><a href="#">Another action</a></li>
												<li><a href="#">Something else here</a></li>
												<li class="divider"></li>
												<li><a href="#">Separated link</a></li>
											  </ul>
											</div>
											<div class="btn-group">
											  <button data-toggle="dropdown" class="btn btn-primary dropdown-toggle">Action <span class="caret"></span></button>
											  <ul class="dropdown-menu">
												<li><a href="#">Action</a></li>
												<li><a href="#">Another action</a></li>
												<li><a href="#">Something else here</a></li>
												<li class="divider"></li>
												<li><a href="#">Separated link</a></li>
											  </ul>
											</div>
											<div style="margin:5px;" class="btn-group">
											  <button data-toggle="dropdown" class="btn btn-danger dropdown-toggle">Danger <span class="caret"></span></button>
											  <ul class="dropdown-menu">
												<li><a href="#">Action</a></li>
												<li><a href="#">Another action</a></li>
												<li><a href="#">Something else here</a></li>
												<li class="divider"></li>
												<li><a href="#">Separated link</a></li>
											  </ul>
											</div>
										  </div>
										  <div >
											<div  class="btn-group">
											  <button data-toggle="dropdown" class="btn btn-warning dropdown-toggle">Warning <span class="caret"></span></button>
											  <ul class="dropdown-menu">
												<li><a href="#">Action</a></li>
												<li><a href="#">Another action</a></li>
												<li><a href="#">Something else here</a></li>
												<li class="divider"></li>
												<li><a href="#">Separated link</a></li>
											  </ul>
											</div>
											<div  class="btn-group">
											  <button data-toggle="dropdown" class="btn btn-success dropdown-toggle">Success <span class="caret"></span></button>
											  <ul class="dropdown-menu">
												<li><a href="#">Action</a></li>
												<li><a href="#">Another action</a></li>
												<li><a href="#">Something else here</a></li>
												<li class="divider"></li>
												<li><a href="#">Separated link</a></li>
											  </ul>
											</div>
											<div class="btn-group">
											  <button data-toggle="dropdown" class="btn btn-info dropdown-toggle">Info <span class="caret"></span></button>
											  <ul class="dropdown-menu">
												<li><a href="#">Action</a></li>
												<li><a href="#">Another action</a></li>
												<li><a href="#">Something else here</a></li>
												<li class="divider"></li>
												<li><a href="#">Separated link</a></li>
											  </ul>
											</div>
											<div class="btn-group">
											  <button data-toggle="dropdown" class="btn btn-inverse dropdown-toggle">Inverse <span class="caret"></span></button>
											  <ul class="dropdown-menu">
												<li><a href="#">Action</a></li>
												<li><a href="#">Another action</a></li>
												<li><a href="#">Something else here</a></li>
												<li class="divider"></li>
												<li><a href="#">Separated link</a></li>
											  </ul>
											</div>
										  </div>
                                       
                                       <h4>Split Button Dropdowns</h4>
                                      
                                       <div style="margin:5px;" class="btn-toolbar">
										<div class="btn-group">
										  <button class="btn">Action</button>
										  <button data-toggle="dropdown" class="btn dropdown-toggle"><span class="caret"></span></button>
										  <ul class="dropdown-menu">
											<li><a href="#">Action</a></li>
											<li><a href="#">Another action</a></li>
											<li><a href="#">Something else here</a></li>
											<li class="divider"></li>
											<li><a href="#">Separated link</a></li>
										  </ul>
										</div>
										<div class="btn-group">
										  <button class="btn btn-primary">Action</button>
										  <button data-toggle="dropdown" class="btn btn-primary dropdown-toggle"><span class="caret"></span></button>
										  <ul class="dropdown-menu">
											<li><a href="#">Action</a></li>
											<li><a href="#">Another action</a></li>
											<li><a href="#">Something else here</a></li>
											<li class="divider"></li>
											<li><a href="#">Separated link</a></li>
										  </ul>
										</div>
										<div class="btn-group">
										  <button class="btn btn-danger">Danger</button>
										  <button data-toggle="dropdown" class="btn btn-danger dropdown-toggle"><span class="caret"></span></button>
										  <ul class="dropdown-menu">
											<li><a href="#">Action</a></li>
											<li><a href="#">Another action</a></li>
											<li><a href="#">Something else here</a></li>
											<li class="divider"></li>
											<li><a href="#">Separated link</a></li>
										  </ul>
										</div>
									  </div>
									  <div style="margin:5px;" class="btn-toolbar">
										<div class="btn-group">
										  <button class="btn btn-warning">Warning</button>
										  <button data-toggle="dropdown" class="btn btn-warning dropdown-toggle"><span class="caret"></span></button>
										  <ul class="dropdown-menu">
											<li><a href="#">Action</a></li>
											<li><a href="#">Another action</a></li>
											<li><a href="#">Something else here</a></li>
											<li class="divider"></li>
											<li><a href="#">Separated link</a></li>
										  </ul>
										</div>
										<div class="btn-group">
										  <button class="btn btn-success">Success</button>
										  <button data-toggle="dropdown" class="btn btn-success dropdown-toggle"><span class="caret"></span></button>
										  <ul class="dropdown-menu">
											<li><a href="#">Action</a></li>
											<li><a href="#">Another action</a></li>
											<li><a href="#">Something else here</a></li>
											<li class="divider"></li>
											<li><a href="#">Separated link</a></li>
										  </ul>
										</div>
										<div class="btn-group">
										  <button class="btn btn-info">Info</button>
										  <button data-toggle="dropdown" class="btn btn-info dropdown-toggle"><span class="caret"></span></button>
										  <ul class="dropdown-menu">
											<li><a href="#">Action</a></li>
											<li><a href="#">Another action</a></li>
											<li><a href="#">Something else here</a></li>
											<li class="divider"></li>
											<li><a href="#">Separated link</a></li>
										  </ul>
										</div>
									  </div>
									  <div style="margin:5px;" class="btn-toolbar">
										<div class="btn-group">
										  <button class="btn btn-inverse">Inverse</button>
										  <button data-toggle="dropdown" class="btn btn-inverse dropdown-toggle"><span class="caret"></span></button>
										  <ul class="dropdown-menu">
											<li><a href="#">Action</a></li>
											<li><a href="#">Another action</a></li>
											<li><a href="#">Something else here</a></li>
											<li class="divider"></li>
											<li><a href="#">Separated link</a></li>
										  </ul>
										</div>
									  </div>
                                       

                                       <h4>Buttons With Icons</h4>

                                       
										<p>
											<button class="btn"><i class="icon-eye-open"></i> View</button>
											<button class="btn btn-inverse"><i class="icon-refresh icon-white"></i> Update</button>
											<button class="btn btn-primary"><i class="icon-pencil icon-white"></i> Edit</button>
											<button class="btn btn-danger"><i class="icon-remove icon-white"></i> Delete</button>
										</p>
										<p>And there this is a toolbar icon example</p>
										<div class="btn-group">
											<button class="btn"><i class="icon-step-backward"></i></button>
											<button class="btn"><i class="icon-fast-backward"></i></button>
											<button class="btn"><i class="icon-backward"></i></button>
											<button class="btn"><i class="icon-play"></i></button>
											<button class="btn"><i class="icon-pause"></i></button>
											<button class="btn"><i class="icon-stop"></i></button>
											<button class="btn"><i class="icon-forward"></i></button>
											<button class="btn"><i class="icon-fast-forward"></i></button>
											<button class="btn"><i class="icon-step-forward"></i></button>
										</div>										
									

                                        </div>
                                    </div> 
                              
                    </div>

    </div>
                       <div class="row">
        <div class="col-lg-12">
            <div class="box primary">
                <header>
                    <div class="icons"><i class="icon-building"></i></div>
                    <h5>Default Button</h5>
                    <div class="toolbar">
                        <button class="btn btn-default btn-sm" data-toggle="collapse" data-target="#div1">default</button>
                    </div>
                </header>
                <div class="body collapse in" id="div1">
                    <h3>Default Button</h3>
                    <a href="#" class="btn btn-default">default</a>
                    <a href="#" class="btn btn-primary">primary</a>
                    <a href="#" class="btn btn-danger">danger</a>
                    <a href="#" class="btn btn-success">success</a>
                    <a href="#" class="btn btn-info">info</a>
                    <a href="#" class="btn btn-warning">warning</a>

                   
                    <hr />
                    <h4>Mini Button</h4>
                    <a href="#" class="btn btn-default btn-xs">default</a>
                    <a href="#" class="btn btn-primary btn-xs">primary</a>
                    <a href="#" class="btn btn-danger btn-xs">danger</a>
                    <a href="#" class="btn btn-success btn-xs">success</a>
                    <a href="#" class="btn btn-info btn-xs">info</a>
                    <a href="#" class="btn btn-warning btn-xs">warning</a>

                  
                    <hr />
                    <h4>Small Button</h4>
                    <a href="#" class="btn btn-default btn-sm">default</a>
                    <a href="#" class="btn btn-primary btn-sm">primary</a>
                    <a href="#" class="btn btn-danger btn-sm">danger</a>
                    <a href="#" class="btn btn-success btn-sm">success</a>
                    <a href="#" class="btn btn-info btn-sm">info</a>
                    <a href="#" class="btn btn-warning btn-sm">warning</a>

                   
                    <hr />
                    <h4>Large Button</h4>

                    <a href="#" class="btn btn-default btn-lg">default</a>
                    <a href="#" class="btn btn-primary btn-lg">primary</a>
                    <a href="#" class="btn btn-danger btn-lg">danger</a>
                    <a href="#" class="btn btn-success btn-lg">success</a>
                    <a href="#" class="btn btn-info btn-lg">info</a>
                    <a href="#" class="btn btn-warning btn-lg">warning</a>

                   
                </div>
            </div>
        </div>


        <div class="col-lg-12">
            <div class="box">
                <header>
                    <div class="icons"><i class="icon-building"></i></div>
                    <h5>Line Button</h5>
                    <div class="toolbar">
                        <button class="btn btn-danger btn-sm btn-line" data-toggle="collapse" data-target="#div2">line</button>
                    </div>
                </header>
                <div class="body collapse in" id="div2">
                    <h3>Default Button</h3>
                    <a href="#" class="btn btn-default btn-line">default</a>
                    <a href="#" class="btn btn-primary btn-line">primary</a>
                    <a href="#" class="btn btn-danger btn-line">danger</a>
                    <a href="#" class="btn btn-success btn-line">success</a>
                    <a href="#" class="btn btn-info btn-line">info</a>
                    <a href="#" class="btn btn-warning btn-line">warning</a>

                    
                    <hr />
                    <h4>Mini Button</h4>
                    <a href="#" class="btn btn-default btn-xs btn-line">default</a>
                    <a href="#" class="btn btn-primary btn-xs btn-line">primary</a>
                    <a href="#" class="btn btn-danger btn-xs btn-line">danger</a>
                    <a href="#" class="btn btn-success btn-xs btn-line">success</a>
                    <a href="#" class="btn btn-info btn-xs btn-line">info</a>
                    <a href="#" class="btn btn-warning btn-xs btn-line">warning</a>

                   
                    <hr />
                    <h4>Small Button</h4>
                    <a href="#" class="btn btn-default btn-sm btn-line">default</a>
                    <a href="#" class="btn btn-primary btn-sm btn-line">primary</a>
                    <a href="#" class="btn btn-danger btn-sm btn-line">danger</a>
                    <a href="#" class="btn btn-success btn-sm btn-line">success</a>
                    <a href="#" class="btn btn-info btn-sm btn-line">info</a>
                    <a href="#" class="btn btn-warning btn-sm btn-line">warning</a>

                    
                    <hr />
                    <h4>Large Button</h4>

                    <a href="#" class="btn btn-default btn-lg btn-line">default</a>
                    <a href="#" class="btn btn-primary btn-lg btn-line">primary</a>
                    <a href="#" class="btn btn-danger btn-lg btn-line">danger</a>
                    <a href="#" class="btn btn-success btn-lg btn-line">success</a>
                    <a href="#" class="btn btn-info btn-lg btn-line">info</a>
                    <a href="#" class="btn btn-warning btn-lg btn-line">warning</a>

                   
                </div>
            </div>
        </div>



        <div class="col-lg-12">
            <div class="box primary">
                <header>
                    <div class="icons"><i class="icon-building"></i></div>
                    <h5>Rectangle Button</h5>
                    <div class="toolbar">
                        <button class="btn btn-success btn-sm btn-rect" data-toggle="collapse" data-target="#div3">rectangle</button>
                    </div>
                </header>
                <div class="body collapse in" id="div3">
                    <h3>Default Button</h3>
                    <a href="#" class="btn btn-default btn-rect">default</a>
                    <a href="#" class="btn btn-primary btn-rect">primary</a>
                    <a href="#" class="btn btn-danger btn-rect">danger</a>
                    <a href="#" class="btn btn-success btn-rect">success</a>
                    <a href="#" class="btn btn-info btn-rect">info</a>
                    <a href="#" class="btn btn-warning btn-rect">warning</a>

                  
                    <hr />
                    <h4>Mini Button</h4>
                    <a href="#" class="btn btn-default btn-xs btn-rect">default</a>
                    <a href="#" class="btn btn-primary btn-xs btn-rect">primary</a>
                    <a href="#" class="btn btn-danger btn-xs btn-rect">danger</a>
                    <a href="#" class="btn btn-success btn-xs btn-rect">success</a>
                    <a href="#" class="btn btn-info btn-xs btn-rect">info</a>
                    <a href="#" class="btn btn-warning btn-xs btn-rect">warning</a>

                  
                    <hr />
                    <h4>Small Button</h4>
                    <a href="#" class="btn btn-default btn-sm btn-rect">default</a>
                    <a href="#" class="btn btn-primary btn-sm btn-rect">primary</a>
                    <a href="#" class="btn btn-danger btn-sm btn-rect">danger</a>
                    <a href="#" class="btn btn-success btn-sm btn-rect">success</a>
                    <a href="#" class="btn btn-info btn-sm btn-rect">info</a>
                    <a href="#" class="btn btn-warning btn-sm btn-rect">warning</a>

                 
                    <hr />
                    <h4>Large Button</h4>

                    <a href="#" class="btn btn-default btn-lg btn-rect">default</a>
                    <a href="#" class="btn btn-primary btn-lg btn-rect">primary</a>
                    <a href="#" class="btn btn-danger btn-lg btn-rect">danger</a>
                    <a href="#" class="btn btn-success btn-lg btn-rect">success</a>
                    <a href="#" class="btn btn-info btn-lg btn-rect">info</a>
                    <a href="#" class="btn btn-warning btn-lg btn-rect">warning</a>

                   
                </div>
            </div>
        </div>



        <div class="col-lg-12">
            <div class="box">
                <header>
                    <div class="icons"><i class="icon-building"></i></div>
                    <h5>Circle Button</h5>
                    <div class="toolbar">
                        <button class="btn btn-success btn-sm btn-circle" data-toggle="collapse" data-target="#div4">c</button>
                    </div>
                </header>
                <div class="body collapse in" id="div4">
                    <h3>Default Button</h3>
                    <a href="#" class="btn btn-default btn-circle">de</a>
                    <a href="#" class="btn btn-primary btn-circle">pr</a>
                    <a href="#" class="btn btn-danger btn-circle">da</a>
                    <a href="#" class="btn btn-success btn-circle">su</a>
                    <a href="#" class="btn btn-info btn-circle">in</a>
                    <a href="#" class="btn btn-warning btn-circle">wa</a>

                    
                    <hr />
                    <h4>Mini Button</h4>
                    <a href="#" class="btn btn-default btn-xs btn-circle">d</a>
                    <a href="#" class="btn btn-primary btn-xs btn-circle">p</a>
                    <a href="#" class="btn btn-danger btn-xs btn-circle">d</a>
                    <a href="#" class="btn btn-success btn-xs btn-circle">s</a>
                    <a href="#" class="btn btn-info btn-xs btn-circle">i</a>
                    <a href="#" class="btn btn-warning btn-xs btn-circle">w</a>

                    
                    <hr />
                    <h4>Small Button</h4>
                    <a href="#" class="btn btn-default btn-sm btn-circle">d</a>
                    <a href="#" class="btn btn-primary btn-sm btn-circle">p</a>
                    <a href="#" class="btn btn-danger btn-sm btn-circle">d</a>
                    <a href="#" class="btn btn-success btn-sm btn-circle">s</a>
                    <a href="#" class="btn btn-info btn-sm btn-circle">i</a>
                    <a href="#" class="btn btn-warning btn-sm btn-circle">w</a>

                  
                    <hr />
                    <h4>Large Button</h4>

                    <a href="#" class="btn btn-default btn-lg btn-circle">def</a>
                    <a href="#" class="btn btn-primary btn-lg btn-circle">pri</a>
                    <a href="#" class="btn btn-danger btn-lg btn-circle">dan</a>
                    <a href="#" class="btn btn-success btn-lg btn-circle">suc</a>
                    <a href="#" class="btn btn-info btn-lg btn-circle">inf</a>
                    <a href="#" class="btn btn-warning btn-lg btn-circle">war</a>

                   
                </div>
            </div>
        </div>


        <div class="col-lg-12">
            <div class="box primary">
                <header>
                    <div class="icons"><i class="icon-building"></i></div>
                    <h5>Rounded Button</h5>
                    <div class="toolbar">
                        <button class="btn btn-primary btn-sm btn-round" data-toggle="collapse" data-target="#div5">round</button>
                    </div>
                </header>
                <div class="body collapse in" id="div5">
                    <h3>Default Button</h3>
                    <a href="#" class="btn btn-default btn-round">default</a>
                    <a href="#" class="btn btn-primary btn-round">primary</a>
                    <a href="#" class="btn btn-danger btn-round">danger</a>
                    <a href="#" class="btn btn-success btn-round">success</a>
                    <a href="#" class="btn btn-info btn-round">info</a>
                    <a href="#" class="btn btn-warning btn-round">warning</a>

                    <hr />
                    <h4>Mini Button</h4>
                    <a href="#" class="btn btn-default btn-xs btn-round">default</a>
                    <a href="#" class="btn btn-primary btn-xs btn-round">primary</a>
                    <a href="#" class="btn btn-danger btn-xs btn-round">danger</a>
                    <a href="#" class="btn btn-success btn-xs btn-round">success</a>
                    <a href="#" class="btn btn-info btn-xs btn-round">info</a>
                    <a href="#" class="btn btn-warning btn-xs btn-round">warning</a>

                    
                    <hr />
                    <h4>Small Button</h4>
                    <a href="#" class="btn btn-default btn-sm btn-round">default</a>
                    <a href="#" class="btn btn-primary btn-sm btn-round">primary</a>
                    <a href="#" class="btn btn-danger btn-sm btn-round">danger</a>
                    <a href="#" class="btn btn-success btn-sm btn-round">success</a>
                    <a href="#" class="btn btn-info btn-sm btn-round">info</a>
                    <a href="#" class="btn btn-warning btn-sm btn-round">warning</a>

                    
                    <hr />
                    <h4>Large Button</h4>

                    <a href="#" class="btn btn-default btn-lg btn-round">default</a>
                    <a href="#" class="btn btn-primary btn-lg btn-round">primary</a>
                    <a href="#" class="btn btn-danger btn-lg btn-round">danger</a>
                    <a href="#" class="btn btn-success btn-lg btn-round">success</a>
                    <a href="#" class="btn btn-info btn-lg btn-round">info</a>
                    <a href="#" class="btn btn-warning btn-lg btn-round">warning</a>

                   
                </div>
            </div>
        </div>




        <div class="col-lg-12">
            <div class="box">
                <header>
                    <div class="icons"><i class="icon-building"></i></div>
                    <h5>Flat Button</h5>
                    <div class="toolbar">
                        <button class="btn btn-info btn-sm btn-flat" data-toggle="collapse" data-target="#div6">flat</button>
                    </div>
                </header>
                <div class="body collapse in" id="div6">
                    <h3>Default Button</h3>
                    <a href="#" class="btn btn-default btn-flat">default</a>
                    <a href="#" class="btn btn-primary btn-flat">primary</a>
                    <a href="#" class="btn btn-danger btn-flat">danger</a>
                    <a href="#" class="btn btn-success btn-flat">success</a>
                    <a href="#" class="btn btn-info btn-flat">info</a>
                    <a href="#" class="btn btn-warning btn-flat">warning</a>

                   
                    <hr />
                    <h4>Mini Button</h4>
                    <a href="#" class="btn btn-default btn-xs btn-flat">default</a>
                    <a href="#" class="btn btn-primary btn-xs btn-flat">primary</a>
                    <a href="#" class="btn btn-danger btn-xs btn-flat">danger</a>
                    <a href="#" class="btn btn-success btn-xs btn-flat">success</a>
                    <a href="#" class="btn btn-info btn-xs btn-flat">info</a>
                    <a href="#" class="btn btn-warning btn-xs btn-flat">warning</a>

                   
                    <hr />
                    <h4>Small Button</h4>
                    <a href="#" class="btn btn-default btn-sm btn-flat">default</a>
                    <a href="#" class="btn btn-primary btn-sm btn-flat">primary</a>
                    <a href="#" class="btn btn-danger btn-sm btn-flat">danger</a>
                    <a href="#" class="btn btn-success btn-sm btn-flat">success</a>
                    <a href="#" class="btn btn-info btn-sm btn-flat">info</a>
                    <a href="#" class="btn btn-warning btn-sm btn-flat">warning</a>

                   
                    <hr />
                    <h4>Large Button</h4>

                    <a href="#" class="btn btn-default btn-lg btn-flat">default</a>
                    <a href="#" class="btn btn-primary btn-lg btn-flat">primary</a>
                    <a href="#" class="btn btn-danger btn-lg btn-flat">danger</a>
                    <a href="#" class="btn btn-success btn-lg btn-flat">success</a>
                    <a href="#" class="btn btn-info btn-lg btn-flat">info</a>
                    <a href="#" class="btn btn-warning btn-lg btn-flat">warning</a>

                    
                </div>
            </div>
        </div>
        


        <div class="col-lg-12">
            <div class="box primary">
                <header>
                    <div class="icons"><i class="icon-building"></i></div>
                    <h5>Gradient Button</h5>
                    <div class="toolbar">
                        <button class="btn btn-default btn-sm btn-grad" data-toggle="collapse" data-target="#div7">gradient</button>
                    </div>
                </header>
                <div class="body collapse in" id="div7">
                    <h3>Default Button</h3>
                    <a href="#" class="btn btn-default btn-grad">default</a>
                    <a href="#" class="btn btn-primary btn-grad">primary</a>
                    <a href="#" class="btn btn-danger btn-grad">danger</a>
                    <a href="#" class="btn btn-success btn-grad">success</a>
                    <a href="#" class="btn btn-info btn-grad">info</a>
                    <a href="#" class="btn btn-warning btn-grad">warning</a>

                   
                    <hr />
                    <h4>Mini Button</h4>
                    <a href="#" class="btn btn-default btn-xs btn-grad">default</a>
                    <a href="#" class="btn btn-primary btn-xs btn-grad">primary</a>
                    <a href="#" class="btn btn-danger btn-xs btn-grad">danger</a>
                    <a href="#" class="btn btn-success btn-xs btn-grad">success</a>
                    <a href="#" class="btn btn-info btn-xs btn-grad">info</a>
                    <a href="#" class="btn btn-warning btn-xs btn-grad">warning</a>

                   
                    <hr />
                    <h4>Small Button</h4>
                    <a href="#" class="btn btn-default btn-sm btn-grad">default</a>
                    <a href="#" class="btn btn-primary btn-sm btn-grad">primary</a>
                    <a href="#" class="btn btn-danger btn-sm btn-grad">danger</a>
                    <a href="#" class="btn btn-success btn-sm btn-grad">success</a>
                    <a href="#" class="btn btn-info btn-sm btn-grad">info</a>
                    <a href="#" class="btn btn-warning btn-sm btn-grad">warning</a>

                  
                    <hr />
                    <h4>Large Button</h4>

                    <a href="#" class="btn btn-default btn-lg btn-grad">default</a>
                    <a href="#" class="btn btn-primary btn-lg btn-grad">primary</a>
                    <a href="#" class="btn btn-danger btn-lg btn-grad">danger</a>
                    <a href="#" class="btn btn-success btn-lg btn-grad">success</a>
                    <a href="#" class="btn btn-info btn-lg btn-grad">info</a>
                    <a href="#" class="btn btn-warning btn-lg btn-grad">warning</a>

                    
                </div>
            </div>
        </div>
        


        <div class="col-lg-12">
            <div class="box">
                <header>
                    <div class="icons"><i class="icon-building"></i></div>
                    <h5>Gradient & Rectangle Button</h5>
                    <div class="toolbar">
                        <button class="btn btn-default btn-sm btn-grad btn-rect" data-toggle="collapse" data-target="#div8">gradient & rectangle</button>
                    </div>
                </header>
                <div class="body collapse in" id="div8">
                    <h3>Default Button</h3>
                    <a href="#" class="btn btn-default btn-grad btn-rect">default</a>
                    <a href="#" class="btn btn-primary btn-grad btn-rect">primary</a>
                    <a href="#" class="btn btn-danger btn-grad btn-rect">danger</a>
                    <a href="#" class="btn btn-success btn-grad btn-rect">success</a>
                    <a href="#" class="btn btn-info btn-grad btn-rect">info</a>
                    <a href="#" class="btn btn-warning btn-grad btn-rect">warning</a>

                   
                    <hr />
                    <h4>Mini Button</h4>
                    <a href="#" class="btn btn-default btn-xs btn-grad btn-rect">default</a>
                    <a href="#" class="btn btn-primary btn-xs btn-grad btn-rect">primary</a>
                    <a href="#" class="btn btn-danger btn-xs btn-grad btn-rect">danger</a>
                    <a href="#" class="btn btn-success btn-xs btn-grad btn-rect">success</a>
                    <a href="#" class="btn btn-info btn-xs btn-grad btn-rect">info</a>
                    <a href="#" class="btn btn-warning btn-xs btn-grad btn-rect">warning</a>

                    
                    <hr />
                    <h4>Small Button</h4>
                    <a href="#" class="btn btn-default btn-sm btn-grad btn-rect">default</a>
                    <a href="#" class="btn btn-primary btn-sm btn-grad btn-rect">primary</a>
                    <a href="#" class="btn btn-danger btn-sm btn-grad btn-rect">danger</a>
                    <a href="#" class="btn btn-success btn-sm btn-grad btn-rect">success</a>
                    <a href="#" class="btn btn-info btn-sm btn-grad btn-rect">info</a>
                    <a href="#" class="btn btn-warning btn-sm btn-grad btn-rect">warning</a>

                    
                    <hr />
                    <h4>Large Button</h4>

                    <a href="#" class="btn btn-default btn-lg btn-grad btn-rect">default</a>
                    <a href="#" class="btn btn-primary btn-lg btn-grad btn-rect">primary</a>
                    <a href="#" class="btn btn-danger btn-lg btn-grad btn-rect">danger</a>
                    <a href="#" class="btn btn-success btn-lg btn-grad btn-rect">success</a>
                    <a href="#" class="btn btn-info btn-lg btn-grad btn-rect">info</a>
                    <a href="#" class="btn btn-warning btn-lg btn-grad btn-rect">warning</a>

                   
                </div>
            </div>
        </div>
       


        <div class="col-lg-12">
            <div class="box">
                <header>
                    <div class="icons"><i class="icon-building"></i></div>
                    <h5>Flat & Rectangle Button</h5>
                    <div class="toolbar">
                        <button class="btn btn-info btn-sm btn-flat btn-rect" data-toggle="collapse" data-target="#div9">flat & rectangle</button>
                    </div>
                </header>
                <div class="body collapse in" id="div9">
                    <h3>Default Button</h3>
                    <a href="#" class="btn btn-default btn-flat btn-rect">default</a>
                    <a href="#" class="btn btn-primary btn-flat btn-rect">primary</a>
                    <a href="#" class="btn btn-danger btn-flat btn-rect">danger</a>
                    <a href="#" class="btn btn-success btn-flat btn-rect">success</a>
                    <a href="#" class="btn btn-info btn-flat btn-rect">info</a>
                    <a href="#" class="btn btn-warning btn-flat btn-rect">warning</a>

                   
                    <hr />
                    <h4>Mini Button</h4>
                    <a href="#" class="btn btn-default btn-xs btn-flat btn-rect">default</a>
                    <a href="#" class="btn btn-primary btn-xs btn-flat btn-rect">primary</a>
                    <a href="#" class="btn btn-danger btn-xs btn-flat btn-rect">danger</a>
                    <a href="#" class="btn btn-success btn-xs btn-flat btn-rect">success</a>
                    <a href="#" class="btn btn-info btn-xs btn-flat btn-rect">info</a>
                    <a href="#" class="btn btn-warning btn-xs btn-flat btn-rect">warning</a>

                  
                    <hr />
                    <h4>Small Button</h4>
                    <a href="#" class="btn btn-default btn-sm btn-flat btn-rect">default</a>
                    <a href="#" class="btn btn-primary btn-sm btn-flat btn-rect">primary</a>
                    <a href="#" class="btn btn-danger btn-sm btn-flat btn-rect">danger</a>
                    <a href="#" class="btn btn-success btn-sm btn-flat btn-rect">success</a>
                    <a href="#" class="btn btn-info btn-sm btn-flat btn-rect">info</a>
                    <a href="#" class="btn btn-warning btn-sm btn-flat btn-rect">warning</a>

                   
                    <hr />
                    <h4>Large Button</h4>

                    <a href="#" class="btn btn-default btn-lg btn-flat btn-rect">default</a>
                    <a href="#" class="btn btn-primary btn-lg btn-flat btn-rect">primary</a>
                    <a href="#" class="btn btn-danger btn-lg btn-flat btn-rect">danger</a>
                    <a href="#" class="btn btn-success btn-lg btn-flat btn-rect">success</a>
                    <a href="#" class="btn btn-info btn-lg btn-flat btn-rect">info</a>
                    <a href="#" class="btn btn-warning btn-lg btn-flat btn-rect">warning</a>

                   
                </div>
            </div>
        </div>
       


        <div class="col-lg-12">
            <div class="box primary">
                <header>
                    <div class="icons"><i class="icon-building"></i></div>
                    <h5>Line & Rectangle Button</h5>
                    <div class="toolbar">
                        <button class="btn btn-info btn-sm btn-line btn-rect" data-toggle="collapse" data-target="#div10">line & rectangle</button>
                    </div>
                </header>
                <div class="body collapse in" id="div10">
                    <h3>Default Button</h3>
                    <a href="#" class="btn btn-default btn-line btn-rect">default</a>
                    <a href="#" class="btn btn-primary btn-line btn-rect">primary</a>
                    <a href="#" class="btn btn-danger btn-line btn-rect">danger</a>
                    <a href="#" class="btn btn-success btn-line btn-rect">success</a>
                    <a href="#" class="btn btn-info btn-line btn-rect">info</a>
                    <a href="#" class="btn btn-warning btn-line btn-rect">warning</a>

                    
                    <hr />
                    <h4>Mini Button</h4>
                    <a href="#" class="btn btn-default btn-xs btn-line btn-rect">default</a>
                    <a href="#" class="btn btn-primary btn-xs btn-line btn-rect">primary</a>
                    <a href="#" class="btn btn-danger btn-xs btn-line btn-rect">danger</a>
                    <a href="#" class="btn btn-success btn-xs btn-line btn-rect">success</a>
                    <a href="#" class="btn btn-info btn-xs btn-line btn-rect">info</a>
                    <a href="#" class="btn btn-warning btn-xs btn-line btn-rect">warning</a>

                   
                    <hr />
                    <h4>Small Button</h4>
                    <a href="#" class="btn btn-default btn-sm btn-line btn-rect">default</a>
                    <a href="#" class="btn btn-primary btn-sm btn-line btn-rect">primary</a>
                    <a href="#" class="btn btn-danger btn-sm btn-line btn-rect">danger</a>
                    <a href="#" class="btn btn-success btn-sm btn-line btn-rect">success</a>
                    <a href="#" class="btn btn-info btn-sm btn-line btn-rect">info</a>
                    <a href="#" class="btn btn-warning btn-sm btn-line btn-rect">warning</a>

                    
                    <hr />
                    <h4>Large Button</h4>

                    <a href="#" class="btn btn-default btn-lg btn-line btn-rect">default</a>
                    <a href="#" class="btn btn-primary btn-lg btn-line btn-rect">primary</a>
                    <a href="#" class="btn btn-danger btn-lg btn-line btn-rect">danger</a>
                    <a href="#" class="btn btn-success btn-lg btn-line btn-rect">success</a>
                    <a href="#" class="btn btn-info btn-lg btn-line btn-rect">info</a>
                    <a href="#" class="btn btn-warning btn-lg btn-line btn-rect">warning</a>

                    
                </div>
            </div>
        </div>
        


        <div class="col-lg-12">
            <div class="box">
                <header>
                    <div class="icons"><i class="icon-building"></i></div>
                    <h5>Circle & Line Button</h5>
                    <div class="toolbar">
                        <button class="btn btn-success btn-sm btn-circle btn-line" data-toggle="collapse" data-target="#div11">c</button>
                    </div>
                </header>
                <div class="body collapse in" id="div11">
                    <h3>Default Button</h3>
                    <a href="#" class="btn btn-default btn-circle btn-line">de</a>
                    <a href="#" class="btn btn-primary btn-circle btn-line">pr</a>
                    <a href="#" class="btn btn-danger btn-circle btn-line">da</a>
                    <a href="#" class="btn btn-success btn-circle btn-line">su</a>
                    <a href="#" class="btn btn-info btn-circle btn-line">in</a>
                    <a href="#" class="btn btn-warning btn-circle btn-line">wa</a>

                   
                    <hr />

                    <h4>Mini Button</h4>
                    <a href="#" class="btn btn-default btn-xs btn-circle btn-line">d</a>
                    <a href="#" class="btn btn-primary btn-xs btn-circle btn-line">p</a>
                    <a href="#" class="btn btn-danger btn-xs btn-circle btn-line">d</a>
                    <a href="#" class="btn btn-success btn-xs btn-circle btn-line">s</a>
                    <a href="#" class="btn btn-info btn-xs btn-circle btn-line">i</a>
                    <a href="#" class="btn btn-warning btn-xs btn-circle btn-line">w</a>

                   
                    <hr />

                    <h4>Small Button</h4>
                    <a href="#" class="btn btn-default btn-sm btn-circle btn-line">d</a>
                    <a href="#" class="btn btn-primary btn-sm btn-circle btn-line">p</a>
                    <a href="#" class="btn btn-danger btn-sm btn-circle btn-line">d</a>
                    <a href="#" class="btn btn-success btn-sm btn-circle btn-line">s</a>
                    <a href="#" class="btn btn-info btn-sm btn-circle btn-line">i</a>
                    <a href="#" class="btn btn-warning btn-sm btn-circle btn-line">w</a>

                   
                    <hr />
                    <h4>Large Button</h4>

                    <a href="#" class="btn btn-default btn-lg btn-circle btn-line">def</a>
                    <a href="#" class="btn btn-primary btn-lg btn-circle btn-line">pri</a>
                    <a href="#" class="btn btn-danger btn-lg btn-circle btn-line">dan</a>
                    <a href="#" class="btn btn-success btn-lg btn-circle btn-line">suc</a>
                    <a href="#" class="btn btn-info btn-lg btn-circle btn-line">inf</a>
                    <a href="#" class="btn btn-warning btn-lg btn-circle btn-line">war</a>

                   
                </div>
            </div>
        </div>
       




        <div class="col-lg-12">
            <div class="box primary">
                <header>
                    <div class="icons"><i class="icon-building"></i></div>
                    <h5>Circle & Gradient Button</h5>
                    <div class="toolbar">
                        <button class="btn btn-success btn-sm btn-circle btn-grad" data-toggle="collapse" data-target="#div12">c</button>
                    </div>
                </header>
                <div class="body collapse in" id="div12">
                    <h3>Default Button</h3>
                    <a href="#" class="btn btn-default btn-circle btn-grad">de</a>
                    <a href="#" class="btn btn-primary btn-circle btn-grad">pr</a>
                    <a href="#" class="btn btn-danger btn-circle btn-grad">da</a>
                    <a href="#" class="btn btn-success btn-circle btn-grad">su</a>
                    <a href="#" class="btn btn-info btn-circle btn-grad">in</a>
                    <a href="#" class="btn btn-warning btn-circle btn-grad">wa</a>

                   
                    <hr />
                    <h4>Mini Button</h4>
                    <a href="#" class="btn btn-default btn-xs btn-circle btn-grad">d</a>
                    <a href="#" class="btn btn-primary btn-xs btn-circle btn-grad">p</a>
                    <a href="#" class="btn btn-danger btn-xs btn-circle btn-grad">d</a>
                    <a href="#" class="btn btn-success btn-xs btn-circle btn-grad">s</a>
                    <a href="#" class="btn btn-info btn-xs btn-circle btn-grad">i</a>
                    <a href="#" class="btn btn-warning btn-xs btn-circle btn-grad">w</a>

                   
                    <hr />
                    <h4>Small Button</h4>
                    <a href="#" class="btn btn-default btn-sm btn-circle btn-grad">d</a>
                    <a href="#" class="btn btn-primary btn-sm btn-circle btn-grad">p</a>
                    <a href="#" class="btn btn-danger btn-sm btn-circle btn-grad">d</a>
                    <a href="#" class="btn btn-success btn-sm btn-circle btn-grad">s</a>
                    <a href="#" class="btn btn-info btn-sm btn-circle btn-grad">i</a>
                    <a href="#" class="btn btn-warning btn-sm btn-circle btn-grad">w</a>

                    
                    <hr />
                    <h4>Large Button</h4>

                    <a href="#" class="btn btn-default btn-lg btn-circle btn-grad">def</a>
                    <a href="#" class="btn btn-primary btn-lg btn-circle btn-grad">pri</a>
                    <a href="#" class="btn btn-danger btn-lg btn-circle btn-grad">dan</a>
                    <a href="#" class="btn btn-success btn-lg btn-circle btn-grad">suc</a>
                    <a href="#" class="btn btn-info btn-lg btn-circle btn-grad">inf</a>
                    <a href="#" class="btn btn-warning btn-lg btn-circle btn-grad">war</a>

                    
                </div>
            </div>
        </div>
      



        <div class="col-lg-12">
            <div class="box">
                <header>
                    <div class="icons"><i class="icon-building"></i></div>
                    <h5>Rounded & Line Button</h5>
                    <div class="toolbar">
                        <button class="btn btn-primary btn-sm btn-round btn-line" data-toggle="collapse" data-target="#div13">round & line</button>
                    </div>
                </header>
                <div class="body collapse in" id="div13">
                    <h3>Default Button</h3>
                    <a href="#" class="btn btn-default btn-round btn-line">default</a>
                    <a href="#" class="btn btn-primary btn-round btn-line">primary</a>
                    <a href="#" class="btn btn-danger btn-round btn-line">danger</a>
                    <a href="#" class="btn btn-success btn-round btn-line">success</a>
                    <a href="#" class="btn btn-info btn-round btn-line">info</a>
                    <a href="#" class="btn btn-warning btn-round btn-line">warning</a>

                   
                    <hr />
                    <h4>Mini Button</h4>
                    <a href="#" class="btn btn-default btn-xs btn-round btn-line">default</a>
                    <a href="#" class="btn btn-primary btn-xs btn-round btn-line">primary</a>
                    <a href="#" class="btn btn-danger btn-xs btn-round btn-line">danger</a>
                    <a href="#" class="btn btn-success btn-xs btn-round btn-line">success</a>
                    <a href="#" class="btn btn-info btn-xs btn-round btn-line">info</a>
                    <a href="#" class="btn btn-warning btn-xs btn-round btn-line">warning</a>

                    <hr />
                    <h4>Small Button</h4>
                    <a href="#" class="btn btn-default btn-sm btn-round btn-line">default</a>
                    <a href="#" class="btn btn-primary btn-sm btn-round btn-line">primary</a>
                    <a href="#" class="btn btn-danger btn-sm btn-round btn-line">danger</a>
                    <a href="#" class="btn btn-success btn-sm btn-round btn-line">success</a>
                    <a href="#" class="btn btn-info btn-sm btn-round btn-line">info</a>
                    <a href="#" class="btn btn-warning btn-sm btn-round btn-line">warning</a>

                   
                    <hr />
                    <h4>Large Button</h4>

                    <a href="#" class="btn btn-default btn-lg btn-round btn-line">default</a>
                    <a href="#" class="btn btn-primary btn-lg btn-round btn-line">primary</a>
                    <a href="#" class="btn btn-danger btn-lg btn-round btn-line">danger</a>
                    <a href="#" class="btn btn-success btn-lg btn-round btn-line">success</a>
                    <a href="#" class="btn btn-info btn-lg btn-round btn-line">info</a>
                    <a href="#" class="btn btn-warning btn-lg btn-round btn-line">warning</a>

                   
                </div>
            </div>
        </div>
        
  </div>
                           
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="panel panel-default">
                        <div class="panel-heading">
                            Social Buttons with Icons
                        </div>
                        <div class="panel-body">
                          
                            <a class="btn btn-block btn-social btn-bitbucket">
                                <i class="icon-bitbucket"></i> Sign in with Bitbucket
                            </a>
                            <a class="btn btn-block btn-social btn-dropbox">
                                <i class="icon-dropbox"></i> Sign in with Dropbox
                            </a>
                            <a class="btn btn-block btn-social btn-facebook">
                                <i class="icon-facebook"></i> Sign in with Facebook
                            </a>
                            <a class="btn btn-block btn-social btn-flickr">
                                <i class="icon-flickr"></i> Sign in with Flickr
                            </a>
                            <a class="btn btn-block btn-social btn-github">
                                <i class="icon-github"></i> Sign in with GitHub
                            </a>
                            <a class="btn btn-block btn-social btn-google-plus">
                                <i class="icon-google-plus"></i> Sign in with Google
                            </a>
                           

                            

                            
                        </div>
                    </div>
                        </div>
                        <div class="col-lg-4">
                             <div class="panel panel-default">
                        <div class="panel-heading">
                            Social Buttons Icons
                        </div>
                        <div class="panel-body">
                            
                            <a class="btn btn-block btn-social btn-instagram">
                                <i class="icon-instagram"></i> Sign in with Instagram
                            </a>
                            <a class="btn btn-block btn-social btn-linkedin">
                                <i class="icon-linkedin"></i> Sign in with LinkedIn
                            </a>
                            <a class="btn btn-block btn-social btn-pinterest">
                                <i class="icon-pinterest"></i> Sign in with Pinterest
                            </a>
                            <a class="btn btn-block btn-social btn-tumblr">
                                <i class="icon-tumblr"></i> Sign in with Tumblr
                            </a>
                            <a class="btn btn-block btn-social btn-twitter">
                                <i class="icon-twitter"></i> Sign in with Twitter
                            </a>
                            <a class="btn btn-block btn-social btn-vk">
                                <i class="icon-vk"></i> Sign in with VK
                            </a>

                        
                            </div>
                                 </div>
                        </div>
                        <div class="col-lg-4">
                             <div class="panel panel-default">
                        <div class="panel-heading">
                          Small Social Buttons with Icons
                        </div>
                        <div class="panel-body">
                            


                            <div class="text-center">
                                <a class="btn btn-social-icon btn-bitbucket"><i class="icon-bitbucket"></i></a>
                                <a class="btn btn-social-icon btn-dropbox"><i class="icon-dropbox"></i></a>
                                <a class="btn btn-social-icon btn-facebook"><i class="icon-facebook"></i></a>
                                <a class="btn btn-social-icon btn-flickr"><i class="icon-flickr"></i></a>
                                <a class="btn btn-social-icon btn-github"><i class="icon-github"></i></a>
                                <a class="btn btn-social-icon btn-google-plus"><i class="icon-google-plus"></i></a>
                                <a class="btn btn-social-icon btn-instagram"><i class="icon-instagram"></i></a>
                                <a class="btn btn-social-icon btn-linkedin"><i class="icon-linkedin"></i></a>
                                <a class="btn btn-social-icon btn-pinterest"><i class="icon-pinterest"></i></a>
                                <a class="btn btn-social-icon btn-tumblr"><i class="icon-tumblr"></i></a>
                                <a class="btn btn-social-icon btn-twitter"><i class="icon-twitter"></i></a>
                                <a class="btn btn-social-icon btn-vk"><i class="icon-vk"></i></a>
                            </div>
                            </div>
                                 </div>
                        </div>
                    </div>
                            
                        </div>
                                       
                   
                     

                    
                    </div>              
             <!--END PAGE CONTENT -->            
                 </div>    
    <!--END MAIN WRAPPER -->
   <!-- FOOTER -->
    <div id="footer">
        <p>&copy;  binarytheme &nbsp;2014 &nbsp;</p>
    </div>
    <!--END FOOTER -->
     <!-- GLOBAL SCRIPTS -->
    <script src="assets/plugins/jquery-2.0.3.min.js"></script>
     <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/plugins/modernizr-2.6.2-respond-1.1.0.min.js"></script>
    <!-- END GLOBAL SCRIPTS -->       
</body>

    <!-- END BODY-->
</html>
