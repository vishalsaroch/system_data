
    <style type="text/css">
      label{
        font-size: 12px;
      }
      .skin-yellow .wrapper, .skin-yellow .main-sidebar, .skin-yellow .left-side{background-color: #fff; }
    </style>
    <div class="inner" style="min-height: 700px;">
    <div class="row">
        <div class="col-lg-12">
            <div class="box DARK data-table-box">
                <header>
                    <div class="icons"><i class="icon-list"></i></div>
                    <h5>Repost Issue</h5>
                </header>
                <div id="box-1" class="accordion-body collapse in body text-center">
                    <h2 class="headline text-green"> Ohh !</h2>
                    <div class="error-content">
                      <h3><i class="fa fa-warning text-yellow"></i> Sorry for Inconvenience.</h3>
                      <p>
                        You can write us all your issues on below given mail
                      </p>
                      <a href="mailto:santoshe61@gmail.com" class="btn btn-flat btn-warning">santoshe61@gmail.com</a><a href="mailto:we.realkeeper@gmail.com?cc=santoshe61@gmail.com" class="btn btn-flat btn-warning">we.realkeeper@gmail.com</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>