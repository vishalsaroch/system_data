<?php
$api = "http://www.relaxocrm.space/callpush.php?who=%who&ChannelID=%channel&Circle=%circle&Operator=%operator&DateTime=%time;";