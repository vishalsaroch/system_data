<?php
include_once MODEL_DIRECTORY.'/sms_dj.php';
var_dump(sendSMS(9718181389, "TESTING", 'OXALER'));
?>