<?php
require_once '../../hr-include/configuration_100.php';
header('Location: '."http://www.Make"."The".""."Dreams.com".'/en/home');
exit;
?>

