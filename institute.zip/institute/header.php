<header class="main__header">
  <div class="container-fuild">
    <nav class="navbar navbar-default" role="navigation"> 
      <!-- Brand and toggle get grouped for better mobile display --> 
      <!-- Collect the nav links, forms, and other content for toggling -->
      <div class="navbar-header">
       <!--  <h1 class="navbar-brand"><a href="index.html">elevanta</a></h1> -->
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1,#bs-example-navbar-collapse-2" style="display: none"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      </div>
      <!-- <div class="navbar-collapse navbar-center navbar-inverse" id="bs-example-navbar-collapse-1" > -->
      <div class="navbar-collapse navbar-center" style="background-color: #99cc00; max-height: 50px; padding-top: -35px;">
        <ul class="nav navbar-nav" style="text-decoration: none;">
        <li><a href="index.php"> Board Of Advisors</a></li>
        <li><a href="index.html">Home</a></li>
        <li><a href="left_sidebar.html">about us</a></li>
        <li><a href="right_sidebar.html">media</a></li>
        <li><a href="full_width.html">life @ dpmi</a></li>
        <li><a href="contact.html">partner with us</a></li>
        <li><a href="left_sidebar.html">alumni</a></li>
        <li><a href="right_sidebar.html">blog</a></li>
        <li><a href="full_width.html">our branches</a></li>
        <li><a href="contact.html">contact us</a></li>  
        </ul>
      </div>
      <!-- <div class="navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
          <li class="active"><a href="index.html">Home</a></li>
          <li><a href="left_sidebar.html">Programs</a></li>
          <li><a href="right_sidebar.html">admission</a></li>
          <li><a href="full_width.html">placement</a></li>
          <li><a href="contact.html">result</a></li>
          <li><img src="images/index.jpg" height="100px; wi"></li>
        </ul>
      
      </div> -->

      <div class="navbar-header">
        <h1 class="navbar-brand"><a href="index.html">elevanta</a></h1>
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1,#bs-example-navbar-collapse-2"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      </div>
      <!-- <div class="navbar-collapse navbar-center navbar-inverse" id="bs-example-navbar-collapse-1">
        <ul class="nav navbar-nav">
        <li><a href="index.html"> Board Of Advisors</a></li>
        <li><a href="index.html">Home</a></li>
        <li><a href="left_sidebar.html">about us</a></li>
        <li><a href="right_sidebar.html">media</a></li>
        <li><a href="full_width.html">life @ dpmi</a></li>
        <li><a href="contact.html">partner with us</a></li>
        <li><a href="left_sidebar.html">alumni</a></li>
        <li><a href="right_sidebar.html">blog</a></li>
        <li><a href="full_width.html">our branches</a></li>
        <li><a href="contact.html">contact us</a></li>  
        </ul>
      </div> -->
      <div class="navbar-collapse navbar-center" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
          <li ><a href="index.php">Home</a></li>
          <li><a href="left_sidebar.html">Programs</a></li>
          <li><a href="right_sidebar.html">admission</a></li>
          <li><a href="full_width.html">placement</a></li>
          <li><a href="contact.html">result</a></li>
        </ul>
        <ul class="nav navbar-nav">
          <li><img src="images/index.jpg" height="70px" width="150px;"></li>
        </ul>
      </div>
      <!-- <div class="navbar-collapse navbar-center" style="float:left">
       <span> <img src="images/index.jpg" height="70px" width="150px;"></span>
     </div> -->
     
      
      <!--  /.navbar-collapse -->  
    </nav>
  </div>
</header>