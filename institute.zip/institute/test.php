<html>
<head>
<title>Create PHP script for Multiple Choice Question</title>
</head>
<body bgcolor=ffffff>
<center>
<table width=728 height=90 bgcolor=AAAAFF border=1><tr><td align=center>
<h3>
Do you want to create a <font color=red>unique HTML/JavaScript page</font> containing all your<br>multiple-choice questions <font color=red>classified in several categories</font>?
</h3>
Check the demo <a href=http://www.testak.org/sample/en.htm target=ne_w>here</a>, or try the free service <a href=http://www.testak.org/ target=ne_w>here</a>.

</td><tr></table>

<br>
<table width="80%" border="0">
<tbody>
<tr>
<td>
<h2>Create PHP script for Multiple Choice Questions<br>
</h2>
<b><a href="index.php?howitwords">How it works</a> | <a href="example.php">Example Quiz</a> | <a href="/Contact_form.php">Contact</a>
<hr style="width: 100%; height: 2px;">
<big><span
style="font-weight: bold;">Create Multiple Choice Questions </span></big><br>
<br>
<form method="post" action="addtest.php">&nbsp;&nbsp;&nbsp;
Number of Questions in the quiz:
<select name="items">
<option>1</option>
<option>2</option>
<option>3</option>
<option>4</option>
<option>5</option>
<option>6</option>
<option>7</option>
<option>8</option>
<option>9</option>
<option selected>10</option>
<option>11</option>
<option>12</option>
<option>13</option>
<option>14</option>
<option>15</option>
<option>16</option>
<option>17</option>
<option>18</option>
<option>19</option>
<option>20</option>
<option>21</option>
<option>22</option>
<option>23</option>
<option>24</option>
<option>25</option>
<option>26</option>
<option>27</option>
<option>28</option>
<option>29</option>
<option>30</option>
<option>31</option>
<option>32</option>
<option>33</option>
<option>34</option>
<option>35</option>
<option>36</option>
<option>37</option>
<option>38</option>
<option>39</option>
<option>40</option>
<option>41</option>
<option>42</option>
<option>43</option>
<option>44</option>
<option>45</option>
<option>46</option>
<option>47</option>
<option>48</option>
<option>49</option>
<option>50</option>
galdera. 
</select>
<input type=submit value="Create Quiz">
</form>
</td>
</tr>
</tbody>
</table>
<br>







</center>
</body>
</html>
