<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<form method="post" action="">
<input type="hidden" name="submitted" value="true" />
<label>Zoek in database: <input type="text" name="criteria" /></label>
 
<input type="submit" value="zoeken" /> 
</form>
<?php 
if($_SERVER['SERVER_NAME']=='localhost')
          {
          $servername = "localhost";
          $username = "root";
          $password = "";
          $dbname = "dbase2";
          }
          else if($_SERVER['SERVER_NAME']=='cogentsol.in')
          {
           $servername = "sun";
          $username = "cogentso_root";
          $password = "rootPWD@#";
          $dbname = "cogentso_dbase2";
          }
         $conn = new mysqli($servername, $username, $password, $dbname);
          
          if ($conn->connect_error) {
              die("Connection failed: " . $conn->connect_error);
          }
$criteria = $_POST['criteria'];
if (isset($_POST['submitted'])) {
$data = mysql_query("SELECT * FROM job WHERE jobTitle(titel, auteur, organisatie, categorie, jaar, tags, link, id) AGAINST('$criteria')") or die(mysql_error());    
// $data = mysql_query("SELECT * FROM job WHERE MATCH(titel, auteur, organisatie, categorie, jaar, tags, link, id) AGAINST('$criteria')") or die(mysql_error()); 
$rows = mysql_num_rows($data); 
$pagenum = $_GET['pagenum'];
 if (!(isset($pagenum))) 
 { 
 $pagenum = 1; }
//This is the number of results displayed per page 
 $page_rows = 10; 
 
 //This tells us the page number of our last page 
 $last = ceil($rows/$page_rows); 
 
 //this makes sure the page number isn't below one, or more than our maximum pages 
 if ($pagenum < 1) 
 { 
 $pagenum = 1; 
 } 
 elseif ($pagenum > $last) 
 { 
 $pagenum = $last; 
 } 
 //This sets the range to display in our query 
$max = 'limit ' .($pagenum - 1) * $page_rows .',' .$page_rows;
// Define your colors for the alternating rows 
    $color1 = "#EDFFFF";  
    $color2 = "#FFFFFF";  
    $row_count = 0; 
$data_p = mysql_query("SELECT * FROM data WHERE MATCH(titel, auteur, organisatie, categorie, jaar, tags, link, id) AGAINST('$criteria') ORDER BY jaar DESC $max") or die(mysql_error()); 
echo "<table>"; 
echo "<tr><th>Titel</th><th>Auteur</th><th>Organisatie</th><th>Categorie</th><th text align=\"center\">Jaar</th></tr>"; 
//This is where you display your query results
while($row = mysql_fetch_array( $data_p )) {
$row_color = ($row_count % 2) ? $color1 : $color2; 
echo
    "<tr><td class=\"titel\" bgcolor=\"$row_color\">" .
    "<a href=\"" . $row['link'] . "\">" .
    $row['titel'] .  
     "</td></a><td class=\"auteur\" bgcolor=\"$row_color\">" .
    $row['auteur'] .
     "</td><td class=\"instelling\" bgcolor=\"$row_color\">" .
    $row['organisatie'] .
     "</td><td class=\"categorie\" bgcolor=\"$row_color\">" .
    $row['categorie'] . 
    "</td><td class=\"jaar\" bgcolor=\"$row_color\">" . 
    $row['jaar'] . 
    "</td></tr>";
    
    // Add 1 to the row count 
$row_count++;
 } 
echo "</table>";
echo "</br>";
 echo "<p>";
 
 // This shows the user what page they are on, and the total number of pages
 echo " Pagina $pagenum van de $last<p>";
 
 // First we check if we are on page one. If we are then we don't need a link to the previous page or the first page so we do nothing. If we aren't then we generate links to the first page, and to the previous page.
 if ($pagenum == 1) 
 {
 } 
 else 
 {
 echo " <a href='{$_SERVER['PHP_SELF']}?pagenum=1'> <<-First</a> ";
 echo " ";
 $previous = $pagenum-1;
 echo " <a href='{$_SERVER['PHP_SELF']}?pagenum=$previous'> <-Previous</a> ";
 } 
 //just a spacer
 echo " ---- ";
 //This does the same as above, only checking if we are on the last page, and then generating the Next and Last links
 if ($pagenum == $last) 
 {
 } 
 else {
 $next = $pagenum+1;
 echo " <a href='{$_SERVER['PHP_SELF']}?pagenum=$next'>Next -></a> ";
 echo " ";
 echo " <a href='{$_SERVER['PHP_SELF']}?pagenum=$last'>Last ->></a> ";
 } }
 ?>
</body>
</html>