<?php
/* Displays user information and some useful messages */
session_start();
// echo session_id();
// Check if user is logged in using the session variable
if ( $_SESSION['emplogged_in'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  header("location:../emplogin/index.php");  
  exit();
}
else {
    // Makes it easier to read
    $first_name = $_SESSION['first_name'];
    $last_name = $_SESSION['last_name'];
    $email = $_SESSION['email'];
    $active = $_SESSION['active'];
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Search</title>
  <link rel="icon" href="../images/logo.png" type="image/png">
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.11/summernote-lite.css" rel="stylesheet">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.11/summernote-lite.js"></script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.11/summernote-lite.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:200,300,400,600,700,800,900" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
     <nav class="navbar navbar-expand-lg  ftco_navbar bg-light ftco-navbar-light shadow" id="ftco-navbar  " >
      <div class="container">
        <a href="index.php" class="navbar-brand"><img src="../images/logo.png"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu" style="color: #000;"></span>
        </button>

        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav ml-auto">
          <li class="nav-item active"><a href="dashboard.php" class="nav-link" style="color:#000; font-weight: bold">Dashboard</a></li>
            <li class="nav-item active"><a href="Profile.php" class="nav-link" style="color:#000; font-weight: bold">Profile</a></li>
          
            <li class="nav-item active"><a href="addjob.php" class="nav-link" style="color:#000; font-weight: bold">Add New Job</a></li>

            <li class="nav-item active"><a href="compjob.php" class="nav-link" style="color:#000; font-weight: bold">Our Company Job</a></li>
            
            <li class="dropdown nav-item">
              <a class="dropdown-toggle nav-link" data-toggle="dropdown" href="#" style="text-transform: capitalize; color:#000; font-weight: bold;"><?php echo $first_name;?> <?php echo $last_name;?><span class="caret" ></span></a>
              <ul class="dropdown-menu" style="padding:10px;">
                <li><a href="../emplogin/logout.php">Logout</a></li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
    </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->

    <div class="container">
      <!-- Page Heading -->
      <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800" style="visibility: hidden;">Dashboard</h1>
        <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm" style="visibility: hidden;"><i class="fas fa-download fa-sm text-white-50" ></i> Generate Report</a>
      </div>
      <!-- End of Content Wrapper -->
        <?php
          
          if($_SERVER['SERVER_NAME']=='localhost')
          {
          $servername = "localhost";
          $username = "root";
          $password = "";
          $dbname = "dbase2";
          }
          else if($_SERVER['SERVER_NAME']=='cogentsol.in')
          {
           $servername = "sun";
          $username = "cogentso_root";
          $password = "rootPWD@#";
          $dbname = "cogentso_dbase2";
          }
         
          $conn = new mysqli($servername, $username, $password, $dbname);
          
          if ($conn->connect_error) {
              die("Connection failed: " . $conn->connect_error);
          }
         
          if(count($_POST)>0) {
            $data=$_POST["query"];
             $result = mysqli_query($conn,"SELECT candidate.fname, candidate.lname, candidate.jobtitle, candidate.years, candidate.months, candidate.emailid, candidate.mobileno, candidate.CurrentLocation, employmenthistory.CompanyName, employmenthistory.Industry, employmenthistory.Function, employmenthistory.Position, employmenthistory.CTC, employmenthistory.EmployementPeriod, employmenthistory.Location, employmenthistory.Reason, employmenthistory.role, educational.sno, educational.userid, educational.Qualification, educational.Course, educational.BoardUniversity, educational.Specialization, educational.Year, educational.Location, educational.marks, educational.userid, candidate.userid FROM ((educational INNER JOIN candidate ON educational.userid = candidate.userid) INNER JOIN employmenthistory ON educational.userid = employmenthistory.userid) where candidate.sno ='$data' or educational.userid ORDER BY Qualification DESC LIMIT 1");   
            }
      ?>


      <?php
        $i=0;
        while($row = mysqli_fetch_array($result)) {
      ?> 
      <div class="job-post-item bg-white p-4 d-block d-md-flex align-items-center">
        <h3 class="text-primary" style="display: none;">Candidate Information</h3>
    </div>
    <div class="job-post-item bg-white p-4 d-block d-md-flex align-items-center">
      <div class="mb-4 mb-md-0 mr-5">
      <div class="job-post-item-body d-block d-md-flex">
        <div class="mr-3"><h3 style="text-transform: capitalize;"> <?php echo  $row["fname"];?> <?php echo  $row["lname"];?><h3>
        </div>
      </div>
      <div class="job-post-item-body d-block d-md-flex">
        <div class="mr-3">
          <h6 style="text-transform: capitalize;"> <?php echo  $row["jobtitle"];?> <?php echo  $row["years"];?>.<?php echo  $row["months"];?> year<h6>
          <h6>Email Id : <?php echo  $row["emailid"];?></h6>
          <h6>Contact No : <?php echo  $row["mobileno"];?><h6>
          <h6>Location : <?php echo  $row["CurrentLocation"];?><h6>
          <h6>Course Name : <?php echo  $row["Course"];?><h6>
          <h6>Passing Year : <?php echo  $row["Year"];?><h6>
          <h6>University : <?php echo  $row["BoardUniversity"];?><h6>
          <h6>Marks : <?php echo  $row["marks"];?><h6>
          <h6>Company name : <?php echo  $row["CompanyName"];?><h6>
          <h6>Industry : <?php echo  $row["Industry"];?><h6>
          <h6>Position : <?php echo  $row["Position"];?><h6>
        </div>
      </div>
    </div>
  </div>
   <?php
      $i++;
      }
    ?>
</div>
   

    </div>

      
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.html">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
  
  
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/chart-area-demo.js"></script>
  <script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>
