<?php
  session_start();
  if ( $_SESSION['emplogged_in'] != 1 ) {
    $_SESSION['message'] = "You must log in before viewing your profile page!";
    header("location:../emplogin/index.php");  
    exit();
  }
  else {
    $first_name = $_SESSION['first_name'];
    $last_name = $_SESSION['last_name'];
    $email = $_SESSION['email'];
    $active = $_SESSION['active'];
  }
?>
<?php
  if($_SERVER['SERVER_NAME']=='localhost'){
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "dbase2";
  }
  else if($_SERVER['SERVER_NAME']=='cogentsol.in'){
    $servername = "sun";
    $username = "cogentso_root";
    $password = "rootPWD@#";
    $dbname = "cogentso_dbase2";
  }
  $conn = new mysqli($servername, $username, $password, $dbname);
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  } 
?>

<?php
  $status=$_POST['status'];
  $inid=$_POST['inid'];
  $sql = "UPDATE `interview` SET `status`='".$status."' WHERE `inid`='".$inid."';";
  $run = mysqli_query($conn, $sql);
  if ($run) {
     header("location:interviewstatus.php");
    } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }
?>