<?php
$name = $_POST['fname'];
$lname = $_POST['lname'];
$email = $_POST['email'];
$subject = $_POST['subject'];
// $subject = $_POST['FreeRequirements'];
// $formcontent=" Enquiry Form from Realkeeper.in \n Name: $name \n E-mail :$email \n Requirements: $subject";
// $recipient = "vishalsaroch1995@gmail.com";
// $FreeRequirements = "Enquiry Form from Realkeeper.in";
// $mailheader = "From: $email \r\n";
// mail($recipient, $mailheader) or die("Error!");
// echo "Thank You - We'll get back to you soon!";
$targetEmail = 'vishalsaroch1995@gmail.com';
// $subject = 'Sending e-mails from PHP is fun!';
$message = $_POST['message'];;
$headers = "From: $email";

$mail = mail($targetEmail, $subject, $message, $headers);
// echo $mail;
echo "<script>location='contact.php'</script>";
?>


<a href="index.html">Click Here to Return</a>
