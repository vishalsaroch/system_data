<footer class="site-footer">
      <div class="container">
        <div class="row">
          <div class="col-lg-4">
            <div class="mb-5">
              <h3 class="footer-heading mb-4">About Truelook</h3>
              <p>Truelook is the Best Mens Haircut in Delhi.  Your Truelook experience starts from the moment you walk in the door.</p>
            </div>

            
            
          </div>
          <div class="col-lg-4 mb-5 mb-lg-0">
          </div>

          <div class="col-lg-4 mb-5 mb-lg-0">
          <div class="row mb-5">
              <div class="col-md-12">
                <h3 class="footer-heading mb-4">Quick Menu</h3>
              </div>
              <div class="col-md-6 col-lg-6">
                <ul class="list-unstyled">
                  <li><a href="Index.php">Home</a></li>
                  <li><a href="about.php">Barbers</a></li>
                  <li><a href="about.php">Team</a></li>
                </ul>
              </div>
              <div class="col-md-6 col-lg-6">
                <ul class="list-unstyled">
                  <li><a href="about.php">About Us</a></li>
                  <li><a href="contact.php">Contact Us</a></li>
                  <li><a href="addshop.php">Membership</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="col-md-12">
            <p align="center">Copyright &copy;<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>document.write(new Date().getFullYear());</script> All rights reserved | Design and developed by <a href="https://Realkeeper.in" target="_blank" style="font-weight: bold">Realkeeper Technologies Pvt. Ltd.</a></p>
          </div>
        </div>
    </footer>