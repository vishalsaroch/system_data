<nav class="navbar navbar-fixed-top">                                                                                   
			   <div class="container-fluid">
			    <div class="navbar-header">
			      <button style="border: 1px blue solid;" type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
			        <span style="background-color: blue;" class="icon-bar"></span>
			        <span style="background-color: blue;" class="icon-bar"></span>
			        <span style="background-color: blue;" class="icon-bar"></span>                        
			      </button>
			      <a class="navbar-brand" href="index.php"><img src="images/ashwani.png" style="margin-top: -20px;"></a>
				    </div>
				    <div class="collapse navbar-collapse" id="myNavbar">
				      <ul class="nav navbar-nav navbar-right">
				        <li class="active"><a href="index.php"><span class="glyphicon glyphicon-home"></span> Home </a></li>
				               <li><a href="aboutus.php">About Company</a></li>
				              <li class="dropdown">
				                <a class="dropdown-toggle" data-toggle="dropdown" href="#">Services<span class="caret"></span></a>
				                <ul class="dropdown-menu">
				                  <li><a href="payroll.php">Payroll & Statutory Compliance</a></li>
				                  <li><a href="requirment.php">Recruitment & Staffing</a></li>
				                  <li><a href="training.php">Training</a></li>
				                </ul>
				              </li>
				          <li><a href="contact.php">Contact </a></li>
				          	<li class="dropdown">
				                <a class="dropdown-toggle" data-toggle="dropdown" href="#">Employee Zone<span class="caret"></span></a>
				                
				                <ul class="dropdown-menu">
				                  <li><a href="login2/index.php">Login</a></li>
				                  <li><a href="candidate/as.html">Registration</a></li> 
				                </ul>
				            </li>
				            <li class="dropdown">
				                <a class="dropdown-toggle" data-toggle="dropdown" href="#">Employer Zone<span class="caret"></span></a>
				                <ul class="dropdown-menu">
				                  <li><a href="login/index.php">Login</a></li>
				                  <li><a href="employer/EmployerSignup.html">Registration</a></li>
				                </ul>
				            </li>
				     	</ul>
				    </div>
				  </div>
				</nav>

<!-- <nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
     <a class="navbar-brand" href="index.php"><img src="images/ashwani.png" style="margin-top: -20px;"></a>
    </div>
      
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
				      <ul class="nav navbar-nav navbar-right">
				        <li class="active"><a href="index.php"><span class="glyphicon glyphicon-home"></span> Home </a></li>
				               <li><a href="aboutus.php">About Company</a></li>
				              <li class="dropdown">
				                <a class="dropdown-toggle" data-toggle="dropdown" href="#">Services<span class="caret"></span></a>
				                <ul class="dropdown-menu">
				                  <li><a href="payroll.php">Payroll & Statutory Compliance</a></li>
				                  <li><a href="requirment.php">Recruitment & Staffing</a></li>
				                  <li><a href="training.php">Training</a></li>
				                </ul>
				              </li>
				          <li><a href="contact.php">Contact </a></li>
				            <li class="dropdown">
				                <a class="dropdown-toggle" data-toggle="dropdown" href="#">Employer Zone<span class="caret"></span></a>
				                <ul class="dropdown-menu">
				                  <li><a href="login/index.php">Login</a></li>
				                  <li><a href="candidate/as.php">Registration</a></li> 
				                </ul>
				            </li>
				           <li class="dropdown">
				                <a class="dropdown-toggle" data-toggle="dropdown" href="#">Employee Zone<span class="caret"></span></a>
				                <ul class="dropdown-menu">
				                  <li><a href="login/index.php">Login</a></li>
				                  <li><a href="employer/EmployerSignup.php">Registration</a></li>
				                </ul>
				            </li>
				      </ul>
				    </div>
  
</nav>   -->