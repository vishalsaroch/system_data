<nav class="navbar navbar-inverse navbar-fixed-top ">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#"><img src="images/ashwani.png" style="margin-top: -20px;"></a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="../index.php">Dashboard</a></li>
        <li><a href="candidate.php">Candidate</a></li>
        <li><a href="employer.php">Employer</a></li>
        <li><a href="job.php">Job</a></li>
        <li><a href="contact.php">Contact</a></li>
        <!-- <li>
          <form action="searchpage.php" method="POST" style="margin-top: 13px;">
              <input type="text" name="data">
              <input type="submit" name="submit" value="Search">
          </form>
        </li> -->
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
      </ul>
    </div>
  </div>
</nav>