<nav class="navbar navbar" style="height: 100px; background-color: black; color: white;" >
      <div class="container-fluid">
        <div class="nav-header">
          <a class="navbar-brand" href="#"><img src="images/ashwani1.png" style="width: 100px; margin-left: -20px;"></a>
        </div>
        <ul class="nav navbar-nav">
            <li class="active"><a href="dashbord.php">Dashboard</a></li>
            <li><a href="profile.php">Update Profile</a></li>
            <li><a href="#">My Jobs</a></li>
        </ul>

    <ul class="nav navbar-nav navbar-right">
        
        <li><a href="../login2/logout.php"><span class="glyphicon glyphicon-log-in"></span> Log Out</a></li>
      </ul>
  </div>
</nav>