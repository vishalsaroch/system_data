<!DOCTYPE html>
<html>
<head>
	<title>Requirement</title>
	<link rel="icon" href="images/ashwani.png" type="image/png">
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="footer.css">
   <link rel="stylesheet" type="text/css" href="main.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script type="text/javascript">
  	$(function () {
  $(document).scroll(function () {
	  var $nav = $(".navbar-fixed-top");
	  $nav.toggleClass('scrolled', $(this).scrollTop() > $nav.height());
	});
});
  </script>
</head>
<body>
		<div class="wrapper">
		<div class="header">
			<nav class="navbar-headerbar  navbar-fixed-top">                                                                                   
			   <div class="container-fluid">
			    <div class="navbar-header">
			      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>                        
			      </button>
			      <a class="navbar-brand" href="index.html"><img src="images/ashwani.png" style="margin-top: -20px;"></a>
				    </div>
				    <div class="collapse navbar-collapse" id="myNavbar">
				      <ul class="nav navbar-nav navbar-right">
				        <li class="active"><a href="index.html"><span class="glyphicon glyphicon-home"></span> Home </a></li>
				               <li><a href="aboutus.html">About Company</a></li>
				              <li class="dropdown">
				                <a class="dropdown-toggle" data-toggle="dropdown" href="#">Services<span class="caret"></span></a>
				                <ul class="dropdown-menu">
				                  <li><a href="payroll.html">Payroll & Statutory Compliance</a></li>
				                  <li><a href="requirment.html">Recruitment & Staffing</a></li>
				                  <li><a href="training.html">Training</a></li>
				                </ul>
				              </li>
				          <li><a href="contact.php">Contact </a></li>
				            <li class="dropdown">
				                <a class="dropdown-toggle" data-toggle="dropdown" href="#">Employer Zone<span class="caret"></span></a>
				                <ul class="dropdown-menu">
				                  <li><a href="login/index.php">Login</a></li>
				                  <li><a href="candidate/as.html">Registration</a></li> 
				                </ul>
				            </li>
				           <li class="dropdown">
				                <a class="dropdown-toggle" data-toggle="dropdown" href="#">Employee Zone<span class="caret"></span></a>
				                <ul class="dropdown-menu">
				                  <li><a href="login/index.php">Login</a></li>
				                  <li><a href="employer/EmployerSignup.html">Registration</a></li>
				                </ul>
				            </li>
				      </ul>
				    </div>
				  </div>
				</nav>
			</div>				

		<div class="container">
			<h1 align="center" style="margin-top: 30px; background-color: black;color: white; opacity: 0.5;">Recruitment & Staffing</h1>
			<P> At <b style="color:red;">Cogent Solutions</b>, we believe that we are an extension of our client's HR team and must perform as a responsible representative of their organization. We, further, like to highlight following for comfort level of our prospective clients:</P>

		  <P>Reduction in the employment expenses</P>
		  <P>Minimization of long terms liabilities</P>
		  <P>Retaining the head count</P>
		  <P>Cost effective Quality manpower</P>
		  <P>Meeting the requirement of seasonal increase in the business</P>
		  <P>We have a team of professional Recruitment Consultant  with extensive experience of hiring Retail Sector</P>
		  <P>We work to meet the deadline of project/recruitment</P>
		  <P>We are open and honest in all dealings.</P>
		  <P>A quality level of service which is at the centre of operation and ethos.</P>
			</P><br>

			<b>Inquire Now</b>
		</div>
	</div>
	<!-- <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script> -->
<!------ Include the above in your HEAD tag ---------->

<!-- Footer -->
	<section id="footer">
		<div class="container">
			<div class="row text-center text-xs-center text-sm-left text-md-left">
				<div class="col-xs-12 col-sm-4 col-md-4">
					<h5>Quick links</h5>
					<ul class="list-unstyled quick-links">
						<li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>Home</a></li>
						<li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>About</a></li>
						<li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>FAQ</a></li>
						<li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>Get Started</a></li>
						<li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>Videos</a></li>
					</ul>
				</div>
				<div class="col-xs-12 col-sm-4 col-md-4">
					<h5>Quick links</h5>
					<ul class="list-unstyled quick-links">
						<li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>Home</a></li>
						<li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>About</a></li>
						<li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>FAQ</a></li>
						<li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>Get Started</a></li>
						<li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>Videos</a></li>
					</ul>
				</div>
				<div class="col-xs-12 col-sm-4 col-md-4">
					<h5>Quick links</h5>
					<ul class="list-unstyled quick-links">
						<li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>Home</a></li>
						<li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>About</a></li>
						<li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>FAQ</a></li>
						<li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>Get Started</a></li>
						<li><a href="https://wwwe.sunlimetech.com" title="Design and developed by"><i class="fa fa-angle-double-right"></i>Imprint</a></li>
					</ul>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-5">
					<ul class="list-unstyled list-inline social text-center">
						<li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-facebook"></i></a></li>
						<li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-twitter"></i></a></li>
						<li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-instagram"></i></a></li>
						<li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-google-plus"></i></a></li>
						<li class="list-inline-item"><a href="javascript:void();" target="_blank"><i class="fa fa-envelope"></i></a></li>
					</ul>
				</div>
				</hr>
			</div>	
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-2 text-center text-white">
					<p><u><a href="https://www.nationaltransaction.com/">National Transaction Corporation</a></u> is a Registered MSP/ISO of Elavon, Inc. Georgia [a wholly owned subsidiary of U.S. Bancorp, Minneapolis, MN]</p>
					<p class="h6">&copy All right Reversed.<a class="text-green ml-2" href="https://www.sunlimetech.com" target="_blank">Sunlimetech</a></p>
				</div>
				</hr>
			</div>	
		</div>
	</section>
	<!-- ./Footer -->
</body>
</html>
