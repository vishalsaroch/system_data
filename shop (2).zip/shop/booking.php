<!DOCTYPE html>
<html lang="en">
  <head>
    <title>HairSal &mdash; Colorlib Website Template</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,700,900|Display+Playfair:200,300,400,700"> 
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">

    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/mediaelement@4.2.7/build/mediaelementplayer.min.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/jquery-migrate-3.0.1.min.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.stellar.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/bootstrap-datepicker.min.js"></script>
 
  <script>
    $(function() {
                // #FresherRegister form id
                $("#order").submit(function(e){       
                    e.preventDefault();    
                    var digits = '0123456789';
                    var otp123 = '';
                    // var OTP = '';
                    for (let i = 0; i < 6; i++ ) {
                        otp123 += digits[Math.floor(Math.random() * 10)];
                        // console.log(OTP);
                    }
                    // return OTP;
                  
                  // console.log(OTP);
                  window.alert(otp123);
                  document.getElementById("otpget").innerHTML=otp123;
                  var urlkey2222="http://sms.realkeeper.in/ComposeSMS.aspx?username=nakul&password=8585&sender=TXTSMS&to="+document.getElementById("mobile").value+"&message=Hi, "+document.getElementById("name").value+" your OTP is "+otp123+"&priority=1&dnd=1&unicode=0";

                  if(location.hostname=='localhost')
                    {
                        // urlkey = "/web_project/candidate/ExperinceRegister.php";
                        urlkey = "/shop/otpsubmit.php";
                    }
                    else if(location.hostname=='cogentsol.in')
                    {
                        urlkey = "otpsubmit.php";
                    }
                    $.ajax({
                        url: urlkey2222,
                        method: "GET",
                        success: function(result){
                                      
                          
                                },
                        failure: function(result){}
                    });

                    //return(false);
                    alert("OTP Sent");

                });

                $("#otpvarifie").submit(function(e){       
                    e.preventDefault();
                    var get = document.getElementById("otpget").value;
                    // var get = document.getElementById("otp1").value;
                    window.alert(get);    
                    var conform = document.getElementById("otp").value;
                    if(get == conform) {
                     window.alert("Wrong OTP Entered")
                    } else {
                      window.alert("otp conformed")
                    }
                  

                });
                //   var urlkey2222="http://sms.realkeeper.in/ComposeSMS.aspx?username=nakul&password=8585&sender=TXTSMS&to="+document.getElementById("mobile").value+"&message=Hi, "+document.getElementById("name").value+" your OTP is"+OTP+"&priority=1&dnd=1&unicode=0";

                //   if(location.hostname=='localhost')
                //     {
                //         // urlkey = "/web_project/candidate/ExperinceRegister.php";
                //         urlkey = "/shop/otpsubmit.php";
                //     }
                //     else if(location.hostname=='cogentsol.in')
                //     {
                //         urlkey = "otpsubmit.php";
                //     }
                //     $.ajax({
                //         url: urlkey2222,
                //         method: "GET",
                //         success: function(result){
                                      
                          
                //                 },
                //         failure: function(result){}
                //     });

                //     //return(false);
                //     alert("OTP Sent");
                   
                                 
                // });
            });

</script>
    
  </head>
  <body>
  
  <?php include("nav.php");?>
  
    <div class="slide-one-i tem home-slider owl-carousel">
      <div class="site-blocks-cover inner-page-cover" style="background-image: url(images/haircut-banner.jpg);" data-aos="fade" data-stellar-background-ratio="0.5">
        <div class="container">
          <div class="row align-items-center justify-content-center text-center">
            <div class="col-md-8" data-aos="fade-up" data-aos-delay="400">
              <h2 class="text-white font-weight-light mb-2 display-1">Online Booking</h2>
            </div>
          </div>
        </div>
      </div>  
    </div>

    <div class="site-section bg-light">
      <div class="container">
        <div class="row">
          <div class="col-md-7 mb-5">
            <form action="" id="order" method="post" class="p-5 bg-white">
              <h2 class="mb-4 site-section-heading">Book Now</h2>

              <div class="row form-group">
                <div class="col-md-12 mb-3 mb-md-0">
                  <label class="text-black" for="fname"> Name</label>
                  <input type="text" name="name" id="name" class="form-control" placeholder="First Name">
                </div>
              </div>
              
              <div class="row form-group">
                <div class="col-md-12 mb-3 mb-md-0">
                  <p id="otp"></p>
                  <label class="text-black" for="date">Date</label> 
                  <input type="text" name="date" id="date" class="form-control datepicker px-2" placeholder="Date of visit">
                </div>
              </div>

               <div class="row form-group">
                <div class="col-md-12 mb-3 mb-md-0">
                  <p id="otp"></p>
                  <label class="text-black" for="Time">Time</label> 
                  <input type="time" name="time" id="time" class="form-control timepicker px-2" placeholder="Time of visit">
                </div>
              </div>
               
              <div class="row form-group">
                <div class="col-md-12">
                  <label class="text-black" for="mobile">Mobile Number</label>
                  <input type="text" id="mobile" name="contact" class="form-control" placeholder="Mobile Number"> 
                </div>
              </div>

              <div class="row form-group">
                <div class="col-md-12">
                  <label class="text-black" for="treatment">Service You Want</label>
                  <select name="treatment" name="services" id="treatment" class="form-control">
                    <option value="Hair Cut">Hair Cut</option>
                    <option value="Hair Coloring">Hair Coloring</option>
                    <option value="Shave">Shave</option>
                    <option value="Hair Conditioning">Hair Conditioning</option>
                  </select>
                </div>
              </div>
              
              <div class="row form-group">
                <div class="col-md-12">
                  <label class="text-black" for="note">Notes</label> 
                  <textarea name="notes" id="note" cols="30" rows="5" class="form-control" placeholder="Write your notes or questions here..."></textarea>
                </div>
              </div>

              <div class="row form-group">
                <div class="col-md-12">
                  <input type="submit" name="submit" id="send" value="Send" class="btn btn-primary py-2 px-4 text-white">
                </div>
              </div>
            </form>

          
            <form action="#" id="otpvarifie" method="post" class="p-5 bg-white">
              <div class="row form-group">
                <div class="col-md-12 mb-3 mb-md-0">
                  <label class="text-black" for="otp">OTP</label>
                  <p id="otpget"></p>
                  <!-- <p id="opt1">1234</p> -->
                  <input type="text" name="otp" id="otp" class="form-control" placeholder="OTP">
                </div>
              </div>

               <div class="row form-group">
                <div class="col-md-12 mb-3 mb-md-0">
                  <input type="submit" name="varify" id="varify" value="Varify"  class="btn btn-primary py-2 px-4 text-white">
                </div>
              </div>
            </div>
          <div class="col-md-5">
            
            <div class="p-4 mb-3 bg-white">
              <p class="mb-0 font-weight-bold">Address</p>
              <p class="mb-4">203 Fake St. Mountain View, San Francisco, California, USA</p>

              <p class="mb-0 font-weight-bold">Phone</p>
              <p class="mb-4"><a href="#">+1 232 3235 324</a></p>

              <p class="mb-0 font-weight-bold">Email Address</p>
              <p class="mb-0"><a href="#">youremail@domain.com</a></p>

            </div>
            
            <div class="p-4 mb-3 bg-white">
              <h3 class="h5 text-black mb-3">More Info</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsa ad iure porro mollitia architecto hic consequuntur. Distinctio nisi perferendis dolore, ipsa consectetur? Fugiat quaerat eos qui, libero neque sed nulla.</p>
              <p><a href="#" class="btn btn-primary px-4 py-2 text-white">Get In Touch</a></p>
            </div>

          </div>
        </div>
      </div>
    </div> 


     <div class="site-section">
      <div class="container">
        <div class="row text-center">
          <div class="col-md-12">
            <h2 class="mb-4 text-black">We want your hair to look fabulous</h2>
            <p class="mb-0"><a href="#" class="btn btn-primary py-3 px-5 text-white">Visit Our Salon Now</a></p>
          </div>
        </div>
      </div>
    </div>


    <?php include("footer.php");?>
  </div>

  
  
   <script src="js/aos.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>