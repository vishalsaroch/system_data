<?php
/* Displays user information and some useful messages */
session_start();
// echo session_id();
// Check if user is logged in using the session variable
if ( $_SESSION['logged_in2'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";

  header("location:login2/index.php");  
  exit();
}
else {
    // Makes it easier to read
    $first_name = $_SESSION['first_name'];
    $last_name = $_SESSION['last_name'];
    $email = $_SESSION['email'];
    $active = $_SESSION['active'];
    
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>HairSal &mdash; Colorlib Website Template</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,700,900|Display+Playfair:200,300,400,700"> 
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">

    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/mediaelement@4.2.7/build/mediaelementplayer.min.css">


    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
    <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
</head>
  <body>
 
  <?php 
     
     // Display message about account verification link only once
     if ( isset($_SESSION['message']) )
     {
         echo $_SESSION['message'];
         
         // Don't annoy the user with more messages upon page refresh
         unset( $_SESSION['message'] );
     }
?>
<?php
    // Keep reminding the user this account is not active, until they activate
     if ( !$active ){
         header("location:login2/index.php");
   exit();
     }
     
?>
     <?php
      if($_SERVER['SERVER_NAME']=='localhost'){
              $servername = "localhost";
              $username = "root";
              $password = "";
              $dbname = "shop";
            }
            else if($_SERVER['SERVER_NAME']=='cogentsol.in'){
              $servername = "sun";
              $username = "cogentso_root";
              $password = "rootPWD@#";
              $dbname = "cogentso_dbase2";
            }
            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);
            // Check connection
            if ($conn->connect_error) {
              die("Connection failed: " . $conn->connect_error);
            } 
      ?>


  <div class="site-wrap"> 
    <div class="site-mobile-menu">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>
    <header class="site-navbar py-1" role="banner">
      <div class="container-fluid">
        <div class="row align-items-center">
          <div class="col-6 col-xl-2" data-aos="fade-down">
            <h1 class="mb-0"><a href="index.php" class="text-black h2 mb-0">Hairsal</a></h1>
          </div>
          <div class="col-10 col-md-8 d-none d-xl-block" data-aos="fade-down">
            <nav class="site-navigation position-relative text-right text-lg-center" role="navigation" >

              <ul class="site-menu js-clone-nav mx-auto d-none d-lg-block">
                <li id="home" class=""><a href="index.php?active=home">Home</a></li>
                <li id="haircut"><a href="haircut.php?active=haircut">Haircut</a></li>
                <li id="services"><a href="services.php?active=services">Services</a></li>
                <li id="about"><a href="about.php?active=about">About</a></li>
                
                <li id="contact"><a href="contact.php?active=contact">Contact</a></li>
                <li id="addshop"><a href="addshop.php?active=addshop">Signup</a></li>
                <li id="Login"><a href="login2/logout.php"><span class="glyphicon glyphicon-log-in">Logout</span>
              </ul>
            </nav>
          </div>
         

           

          <div class="col-6 col-xl-2 text-right" data-aos="fade-down">
            <div class="d-none d-xl-inline-block">
              <ul class="site-menu js-clone-nav ml-auto list-unstyled d-flex text-right mb-0" data-class="social">
                <li>
                  <a href="#" class="pl-0 pr-3 text-black"><span class="icon-facebook"></span></a>
                </li>
                <li>
                  <a href="#" class="pl-3 pr-3 text-black"><span class="icon-twitter"></span></a>
                </li>
                <li>
                  <a href="#" class="pl-3 pr-3 text-black"><span class="icon-instagram"></span></a>
                </li>
                <li>
                  <a href="#" class="pl-3 pr-3 text-black"><span class="icon-youtube-play"></span></a>
                </li>
              </ul>
            </div>

            <div class="d-inline-block d-xl-none ml-md-0 mr-auto py-3" style="position: relative; top: 3px;"><a href="#" class="site-menu-toggle js-menu-toggle text-black"><span class="icon-menu h3"></span></a></div>

          </div>

        </div>
      </div>
      
    </header>
    <div class="site-section bg-light">
      <div class="container">
        <div class="row">
         <?php
          if(isset($_POST['submit'])){
              // $shopname = $_POST['shopname'];
              // $ownername = $_POST['ownername'];
              // $mobile = $_POST['mobile'];
              $location = $_POST['location'];
              $GST = $_POST['GST'];
              $services  = $_POST['services'];
              $sql = "UPDATE `shop` SET `location`='".$location."', `GST`='".$GST."', `services`='".$services."' WHERE `userid`='".$_SESSION['email']."';";
              $run = mysqli_query($conn, $sql);
              if ($run) {
                echo "<p>Profile Update Successfully</p>";
                // echo "<script>location='test2.php'</script>";
                } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
                }
              }
          ?>
          <?php
         
          ?>
          <div class="col-md-12">
            <?php

              // $result = mysqli_query($mysqli, "SELECT * FROM users WHERE id=$id");
 
              // while($res = mysqli_fetch_array($result))
              // {
              //     $name = $res['name'];
              //     $age = $res['age'];
              //     $email = $res['email'];
              // }
              $sql = "SELECT * from shop where mobileno = '".$_SESSION['email']."';";
              // $sql = "SELECT * from shop where id = 5";
              $result = $conn->query($sql);
              while($row = $result->fetch_assoc()) {
                $location= $row['location'];
                $services= $row['services'];
                $GST = $row['GST'];
               
              } 
            ?>
            <div class="p-4 mb-3 bg-white">
               <form action="" method="post" id="Register" enctype="multipart/form-data" class="p-5 bg-white">
                      <h2 class="mb-4 site-section-heading">Profile Update</h2>
                        <!-- <div class="col-md-12" style="margin-top: 20px;">
                            <label>Shop Name</label>
                            <input type="text" id ="name123" name="shopname" class="form-control" placeholder="Shop Name *" required />
                        </div>
                        <div class="col-md-12" style="margin-top: 20px;" style="margin-top: 20px;">
                            <label>Owner Name</label>
                            <input type="text" name="ownername" class="form-control" placeholder="Owner Name *"  required />
                        </div>
                        <div class="col-md-12" style="margin-top: 20px;">
                            <label>Mobile Number</label>
                            <input type="number" minlength="10" id="phoneno" maxlength="10" name="mobile" class="form-control" placeholder="Your Phone *"/>
                        </div>
 -->
                        <div class="col-md-12" style="margin-top: 20px;">
                            <label>Location</label>
                            <input type="text" name="location" class="form-control" placeholder="Location *" value="<?php echo $location;?>">
                        </div>
                                                    
                        <div class="col-md-12" style="margin-top: 20px;">
                            <label>GST</label>
                            <input type="text" name="GST" class="form-control" placeholder="$GST *" value="<?php echo $GST;?>" required/>    
                        </div>

                        <div class="col-md-12" style="margin-top: 20px;">
                            <label>Services</label>
                            <input type="text" name="services" class="form-control" value="<?php echo $services;?>" required/>    
                        </div>
                        <div class="col-md-6"style="margin-top: 20px;">
                          <input type="submit" name="submit" class="btn btn-success" value="Update" > 
                        </div>
                        </form>

            </div>
            
            <!-- <div class="p-4 mb-3 bg-white">
              <h3 class="h5 text-black mb-3">More Info</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsa ad iure porro mollitia architecto hic consequuntur. Distinctio nisi perferendis dolore, ipsa consectetur? Fugiat quaerat eos qui, libero neque sed nulla.</p>
              <p><a href="#" class="btn btn-primary px-4 py-2 text-white">Get In Touch</a></p>
            </div> -->

          </div>
        </div>
      </div>
    </div>


    <!-- <div class="site-section">
      <div class="container">
        <div class="row text-center">
          <div class="col-md-12">
            <h2 class="mb-4 text-black">We want your hair to look fabulous</h2>
            <p class="mb-0"><a href="#" class="btn btn-primary py-3 px-5 text-white">Visit Our Salon Now</a></p>
          </div>
        </div>
      </div>
    </div> -->


    <?php include("footer.php");?>

  </div>

<script src="js/aos.js"></script>

  <script src="js/main.js"></script> 
   <script type="text/javascript">
function getQueryStrings() { 
  var assoc  = {};
  var decode = function (s) { return decodeURIComponent(s.replace(/\+/g, " ")); };
  var queryString = location.search.substring(1); 
  var keyValues = queryString.split('&'); 

  for(var i in keyValues) { 
    var key = keyValues[i].split('=');
    if (key.length > 1) {
      assoc[decode(key[0])] = decode(key[1]);
    }
  } 

  return assoc; 
}
      var qs = getQueryStrings();
      var active = qs["active"];
      var att = document.createAttribute("class");
        att.value = "active";
      if(active=="home")
      {        
        document.getElementById("home").setAttributeNode(att);
      }
      if(active=="haircut")
      {        
        document.getElementById("haircut").setAttributeNode(att);
      }
      if(active=="services")
      {        
        document.getElementById("services").setAttributeNode(att);
      }
      if(active=="about")
      {        
        document.getElementById("about").setAttributeNode(att);
      }
      if(active=="contact")
      {        
        document.getElementById("contact").setAttributeNode(att);
      }
      if(active=="addshop")
      {        
        document.getElementById("addshop").setAttributeNode(att);
      }
      if(active=="Login")
      {        
        document.getElementById("Login").setAttributeNode(att);
      }
    </script> 
  </body>
</html>
